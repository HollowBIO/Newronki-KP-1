"""Evaluate the responses with two methods:

1) Heuristic / automatic metrics:
   - length (chars, words)
   - structure score: does the answer have a definition, example, advice (3 parts for v2 prompt);
     looks for keywords like "наприклад", "приклад", "коли", "порада", or 3+ lines/bullets;
   - keyword coverage: fraction of expected concept words present per question.

2) LLM-as-judge: ask the same LLM to grade 3 criteria (RELEVANCE, COMPLETENESS, CLARITY) 1..5.

Average scores per prompt variant are saved for the research.
"""
import json
import re
import sys
from pathlib import Path

import pandas as pd

KP5_DIR = Path(__file__).resolve().parent.parent
RESULTS_DIR = KP5_DIR / "Results"
sys.path.insert(0, str(KP5_DIR / "BotCore"))
from bot import default_llm  # noqa: E402
from prompts import JUDGE_PROMPT  # noqa: E402

# Expected key concepts per question (used in keyword coverage heuristic)
KEYWORDS = {
    0: ["LIFO", "FIFO", "стек", "черг"],   # stack vs queue
    1: ["рекурс", "базов", "виклик"],       # recursion
    2: ["O(1)", "O(n)", "O(n^2)", "O(log", "складн"],  # Big O
    3: ["JOIN", "INNER", "LEFT", "RIGHT", "FULL", "таблиц"],
    4: ["інкапсуляц", "спадкуванн", "поліморфіз", "клас", "об'єкт", "обєкт", "object"],
}


def heuristic_scores(response, qi):
    r = response.lower()
    kws = KEYWORDS.get(qi, [])
    hits = sum(1 for k in kws if k.lower() in r)
    kw_coverage = hits / max(len(kws), 1)

    # Structure score (0..3): looks for 3-part structure (definition/example/advice)
    has_definition = len(response) >= 40
    has_example = any(w in r for w in ["наприклад", "приклад", "code", "```", "def ", "class "])
    has_advice = any(w in r for w in ["коли", "варто", "рекоменду", "порад", "використов"])
    structure = int(has_definition) + int(has_example) + int(has_advice)
    return kw_coverage, structure


JUDGE_RE = re.compile(
    r"RELEVANCE\s*=?\s*(\d).{0,10}COMPLETENESS\s*=?\s*(\d).{0,10}CLARITY\s*=?\s*(\d)",
    re.IGNORECASE | re.DOTALL)


def parse_judge(text):
    m = JUDGE_RE.search(text)
    if m:
        return int(m.group(1)), int(m.group(2)), int(m.group(3))
    # try digits-only fallback: first 3 numbers 1..5
    nums = [int(x) for x in re.findall(r"[1-5]", text)]
    if len(nums) >= 3:
        return nums[0], nums[1], nums[2]
    return None, None, None


def main():
    responses = pd.read_excel(RESULTS_DIR / "responses.xlsx")
    judge = default_llm()  # Qwen (same model) or Gemini when key is set

    rows = []
    for _, r in responses.iterrows():
        qi = int(r["question_idx"])
        pname = r["prompt_name"]
        response = str(r["response"])
        kw, structure = heuristic_scores(response, qi)

        judge_user = f"Питання студента: {r['question']}\n\nВідповідь асистента:\n{response}"
        judge_text, judge_dt = judge.generate(JUDGE_PROMPT, judge_user, max_new_tokens=40,
                                              temperature=0.0)
        rel, comp, clar = parse_judge(judge_text)
        print(f"[{pname} / Q{qi + 1}] kw={kw:.2f} struct={structure}/3  "
              f"judge: R={rel} C={comp} CL={clar}  ({judge_dt:.1f} s)  raw='{judge_text[:80]}'")

        rows.append({
            "prompt_name": pname,
            "question_idx": qi,
            "chars": int(r["chars"]),
            "words": int(r["words"]),
            "latency_s": float(r["latency_s"]),
            "kw_coverage": kw,
            "structure_0to3": structure,
            "judge_relevance": rel,
            "judge_completeness": comp,
            "judge_clarity": clar,
            "judge_raw": judge_text,
        })
    df = pd.DataFrame(rows)
    df.to_excel(RESULTS_DIR / "evaluation.xlsx", index=False)
    print("\nsaved", RESULTS_DIR / "evaluation.xlsx")

    # Summary per prompt variant
    agg = df.groupby("prompt_name").agg({
        "chars": "mean",
        "words": "mean",
        "latency_s": "mean",
        "kw_coverage": "mean",
        "structure_0to3": "mean",
        "judge_relevance": "mean",
        "judge_completeness": "mean",
        "judge_clarity": "mean",
    }).reindex(["basic", "improved_v1", "improved_v2"])
    agg["judge_avg"] = agg[["judge_relevance", "judge_completeness", "judge_clarity"]].mean(axis=1)
    agg.to_excel(RESULTS_DIR / "evaluation_summary.xlsx")
    print(agg.to_string())


if __name__ == "__main__":
    main()
