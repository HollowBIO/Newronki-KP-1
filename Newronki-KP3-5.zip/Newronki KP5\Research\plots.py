"""Plots for KP5 research: compare prompt variants by heuristic + judge scores."""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

KP5 = Path(__file__).resolve().parent.parent
RES = KP5 / "Results"
sys.path.insert(0, str(KP5 / "BotCore"))
from prompts import PROMPT_LABEL_UK  # noqa: E402

ORDER = ["basic", "improved_v1", "improved_v2"]


def main():
    agg = pd.read_excel(RES / "evaluation_summary.xlsx", index_col=0).reindex(ORDER)
    labels = [PROMPT_LABEL_UK[p] for p in ORDER]

    fig, ax = plt.subplots(1, 2, figsize=(12, 4.2))
    judge_cols = ["judge_relevance", "judge_completeness", "judge_clarity"]
    width = 0.25
    for i, col in enumerate(judge_cols):
        ax[0].bar([j + (i - 1) * width for j in range(len(ORDER))],
                  agg[col], width, label=col.replace("judge_", ""))
    ax[0].set_xticks(range(len(ORDER)))
    ax[0].set_xticklabels(labels, rotation=15)
    ax[0].set_ylabel("judge score (1..5)")
    ax[0].set_ylim(0, 5.3)
    ax[0].legend(); ax[0].grid(axis="y", alpha=0.3)
    ax[0].set_title("LLM-as-judge оцінки за критеріями")

    heur_cols = ["kw_coverage", "structure_0to3"]
    for i, col in enumerate(heur_cols):
        ax[1].bar([j + (i - 0.5) * 0.35 for j in range(len(ORDER))],
                  agg[col] / (3 if col == "structure_0to3" else 1), 0.35, label=col)
    ax[1].set_xticks(range(len(ORDER)))
    ax[1].set_xticklabels(labels, rotation=15)
    ax[1].set_ylabel("частка (0..1)")
    ax[1].set_ylim(0, 1.1)
    ax[1].legend(); ax[1].grid(axis="y", alpha=0.3)
    ax[1].set_title("Евристичні метрики (нормалізовані)")

    plt.tight_layout()
    plt.savefig(RES / "research_scores.png", dpi=130, bbox_inches="tight")
    plt.close()
    print("saved", RES / "research_scores.png")

    # Per-question breakdown
    ev = pd.read_excel(RES / "evaluation.xlsx")
    ev["judge_avg"] = ev[["judge_relevance", "judge_completeness", "judge_clarity"]].mean(axis=1)
    piv = ev.pivot_table(index="question_idx", columns="prompt_name",
                         values="judge_avg").reindex(columns=ORDER)
    fig, ax = plt.subplots(figsize=(9, 3.6))
    piv.plot(kind="bar", ax=ax)
    ax.set_xlabel("індекс питання")
    ax.set_ylabel("середня judge-оцінка (1..5)")
    ax.set_title("Judge-оцінки на кожне питання")
    ax.set_xticklabels([f"Q{i + 1}" for i in piv.index], rotation=0)
    ax.legend(labels=[PROMPT_LABEL_UK[c] for c in piv.columns])
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(RES / "research_per_question.png", dpi=130, bbox_inches="tight")
    plt.close()
    print("saved", RES / "research_per_question.png")


if __name__ == "__main__":
    main()
