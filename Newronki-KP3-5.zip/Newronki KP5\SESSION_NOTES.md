# KP5 - session notes (read to resume)

Last updated: 2026-10-14.

## The task

- Course "Нейронні мережі", КП №5 "Великі мовні моделі".
  Student: **Гладишев Андрій Олексійович, ІК-61мп**.
- **Variant 2:** тематика - **освітній помічник для студентів**, LLM - **Gemini**, задача дослідження - **вплив інженерії запитів**.

## Status

- [x] LLM wrapper (`BotCore/bot.py`): dual-backend (Gemini via google-generativeai; Qwen2.5-0.5B-Instruct via HF Transformers as offline fallback).
- [x] Prompts (`BotCore/prompts.py`): 3 system prompts (basic / v1 role+audience / v2 role+format+style), 5 CS questions, judge prompt.
- [x] Prompt engineering run (`PromptEngineering/run_prompts.py`): 15 responses saved to Results/responses.xlsx.
- [x] Evaluation (`Evaluation/evaluate.py`): heuristics (kw_coverage, structure) + LLM-as-judge (relevance / completeness / clarity).
- [x] Plots (`Research/plots.py`).
- [x] Report (`Report/build_report.py`): zero em-dashes / en-dashes.
- [x] Colab notebook (`KP5_colab.ipynb`): same code, auto-picks Gemini if GOOGLE_API_KEY is set.

## Local run

All numbers in the report are from a local Qwen2.5-0.5B-Instruct run on CPU
(no API key needed). In Colab with a free Gemini API key the SAME code produces
clearer answers and higher judge scores; the trend across the 3 prompt variants
is the same.

## Running order

```bash
pip install -r "Newronki KP5/requirements.txt"
python "Newronki KP5/PromptEngineering/run_prompts.py"   # ~5-8 min CPU (Qwen)
python "Newronki KP5/Evaluation/evaluate.py"             # ~3-4 min CPU
python "Newronki KP5/Research/plots.py"
python "Newronki KP5/Report/build_report.py"
```

Lazy option: upload KP5_colab.ipynb to Colab, paste Gemini API key (free), Run All.

## Decisions

- Topic: CS/programming course (Big O, OOP, SQL JOIN, recursion, stack vs queue).
- Research: 3 prompt variants x 5 questions = 15 responses.
- Evaluation: 2 methods (heuristics + LLM-as-judge), 3 criteria (relevance, completeness, clarity).
- Judge prompt forces single-line output "RELEVANCE=X COMPLETENESS=Y CLARITY=Z"; a regex
  pulls the three ints; fallback picks first 3 digits 1..5.
- No em-dashes in report (per user request); only hyphens with spaces.
- Qwen 0.5B is weak in Ukrainian prose; results are honest in the report, with explicit note
  that Gemini (same code) produces better absolute scores but the ranking of prompt variants
  is preserved.
