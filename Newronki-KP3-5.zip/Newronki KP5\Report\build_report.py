"""Builds the KP5 report from the template.

Zero em-dashes anywhere, only plain hyphens with spaces (user request).
"""
import shutil
import sys
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.shared import Cm, Pt
from docx.text.paragraph import Paragraph

REPORT_DIR = Path(__file__).resolve().parent
TEMPLATE = REPORT_DIR / "KP5_template.docx"
KP5 = REPORT_DIR.parent
OUT = REPORT_DIR / "ІК-61мп Гладишев Андрій Олексійович - KP5.docx"
RESULTS = KP5 / "Results"

sys.path.insert(0, str(KP5 / "BotCore"))
from prompts import SYSTEM_PROMPTS, TEST_QUESTIONS, PROMPT_LABEL_UK, PROMPT_ORDER, JUDGE_PROMPT  # noqa: E402


def _series(path):
    df = pd.read_excel(path)
    if "value" in df.columns:
        return dict(zip(df.iloc[:, 0], df["value"]))
    return df.iloc[0].to_dict()


if OUT.exists():
    shutil.copy2(OUT, OUT.with_name(OUT.stem + ".backup.docx"))

doc = Document(TEMPLATE)


def find(prefix, nth=None):
    matches = [p for p in doc.paragraphs if p.text.startswith(prefix)]
    if nth is None:
        assert len(matches) == 1, f"{prefix!r}: {len(matches)} matches"
        nth = 0
    return matches[nth]


def fill(p, text=None):
    for r in list(p.runs):
        if not r.bold:
            r._r.getparent().remove(r._r)
    if text:
        if not p.runs[-1].text.endswith(" "):
            p.runs[-1].text += " "
        p.add_run(text)
    return p


def rewrite(p, label=None, text=None):
    """Clear ALL runs, then add bold label + plain text. For template placeholders."""
    for r in list(p.runs):
        r._r.getparent().remove(r._r)
    if label:
        p.add_run(label + " ").bold = True
    if text:
        p.add_run(text)
    return p


class Cursor:
    def __init__(self, anchor):
        self.el = anchor._p
        self.parent = anchor._parent

    def _new_para(self, align):
        new = OxmlElement("w:p")
        self.el.addnext(new)
        self.el = new
        p = Paragraph(new, self.parent)
        p.alignment = align
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        return p

    def text(self, text, label=None, align=WD_ALIGN_PARAGRAPH.JUSTIFY, size=None, keep_next=False):
        p = self._new_para(align)
        if label:
            p.add_run(label + " ").bold = True
        run = p.add_run(text)
        if size:
            run.font.size = Pt(size)
        p.paragraph_format.keep_with_next = keep_next

    def code(self, lines):
        for i, line in enumerate(lines):
            p = self._new_para(WD_ALIGN_PARAGRAPH.LEFT)
            p.paragraph_format.keep_with_next = i < len(lines) - 1
            run = p.add_run(line)
            run.font.name = "Courier New"
            run.font.size = Pt(10.5)

    def picture(self, path, width_cm, caption):
        p = self._new_para(WD_ALIGN_PARAGRAPH.CENTER)
        p.paragraph_format.keep_with_next = True
        p.add_run().add_picture(str(path), width=Cm(width_cm))
        self.text(caption, align=WD_ALIGN_PARAGRAPH.CENTER, size=12)

    def table(self, caption, rows, widths_cm, size=12):
        self.text(caption, size=12, align=WD_ALIGN_PARAGRAPH.LEFT, keep_next=True)
        table = doc.add_table(rows=len(rows), cols=len(rows[0]))
        table.style = "Table Grid"
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                cell = table.cell(r, c)
                cell.width = Cm(widths_cm[c])
                para = cell.paragraphs[0]
                para.paragraph_format.space_after = Pt(0)
                para.paragraph_format.line_spacing = 1.0
                para.paragraph_format.keep_with_next = r < len(rows) - 1
                para.alignment = WD_ALIGN_PARAGRAPH.LEFT if c == 0 else WD_ALIGN_PARAGRAPH.CENTER
                run = para.add_run(str(value))
                run.font.size = Pt(size)
                run.bold = r == 0
        self.el.addnext(table._tbl)
        self.el = table._tbl


def num(x, d=2):
    return f"{float(x):.{d}f}".replace(".", ",")


def shorten(s, n=350):
    s = str(s).strip().replace("\n\n", "\n")
    return s if len(s) <= n else s[:n].rstrip() + "..."


# ===== Load data from runs ========================================================
responses = pd.read_excel(RESULTS / "responses.xlsx")
evaluation = pd.read_excel(RESULTS / "evaluation.xlsx")
agg = pd.read_excel(RESULTS / "evaluation_summary.xlsx", index_col=0).reindex(PROMPT_ORDER)
backend = responses["backend"].iloc[0]
model_name = responses["model"].iloc[0]

# ===== Header =====================================================================
fill(find("ПІБ:"), "Гладишев Андрій Олексійович")
fill(find("Група:"), "ІК-61мп")
fill(find("Номер варіанту:"), "2")
fill(find("Завдання для варіанту:"),
     "тематика - освітній помічник для студентів-програмістів; LLM - Gemini (за варіантом) з "
     "можливістю заміни на іншу LLM; задача дослідження - вплив інженерії запитів.")

fill(find("Засоби виконання практикуму:"),
     "Windows 11, CPU AMD Ryzen 5 5600 (без GPU) та Google Colab; Python 3.13 / 3.10; "
     "google-generativeai 0.8 для Gemini API; HuggingFace Transformers 4.57 + torch 2.11 як "
     f"резервний бекенд (локальна модель {model_name}); pandas, openpyxl, matplotlib. "
     "Усі експерименти з повним кодом у ноутбуці KP5_colab.ipynb.")

# ===== LLM description =============================================================
if backend == "gemini":
    llm_descr = (
        "Gemini 1.5 Flash - швидка і дешева LLM Google (gemini-1.5-flash) з контекстом до 1 млн "
        "токенів, оптимізована для чатів і коротких задач. Доступ через google-generativeai SDK, "
        "безкоштовний ключ видається в Google AI Studio (https://aistudio.google.com/apikey)."
    )
    code_lines = [
        "import google.generativeai as genai",
        "genai.configure(api_key=os.environ['GOOGLE_API_KEY'])",
        "model = genai.GenerativeModel('gemini-1.5-flash')",
        "resp = model.generate_content(",
        "    system + '\\n\\nПитання: ' + user,",
        "    generation_config={'temperature': 0.0, 'max_output_tokens': 300})",
        "print(resp.text)",
    ]
else:
    llm_descr = (
        f"Основний варіант за завданням - Gemini (gemini-1.5-flash), API Google. "
        f"У цьому прогоні для повної локальної відтворюваності без API-ключа використано "
        f"{model_name} - невелику інструктивно донавчену модель (~{int(responses.get('words', pd.Series()).sum() / 1 or 0)}... "
        f"це опенсорс-альтернатива з HuggingFace, 494 млн параметрів, Apache 2.0). "
        "Код у ноутбуці підтримує обидва бекенди і автоматично перемикається, якщо є "
        "GOOGLE_API_KEY. Поведінка Gemini якісніша, цифри в звіті - з локального прогону Qwen "
        "на CPU."
    )
    code_lines = [
        "from transformers import AutoModelForCausalLM, AutoTokenizer",
        "import torch",
        "name = 'Qwen/Qwen2.5-0.5B-Instruct'",
        "tok = AutoTokenizer.from_pretrained(name)",
        "model = AutoModelForCausalLM.from_pretrained(name, dtype=torch.float32)",
        "msgs = [{'role':'system','content':system},",
        "        {'role':'user',  'content':user}]",
        "prompt = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)",
        "inp = tok(prompt, return_tensors='pt')",
        "out = model.generate(**inp, max_new_tokens=300, do_sample=False,",
        "                     pad_token_id=tok.eos_token_id)",
        "print(tok.decode(out[0][inp.input_ids.shape[1]:], skip_special_tokens=True))",
    ]

p = fill(find("LLM:"), llm_descr)
Cursor(p).code(code_lines)

# ===== Prompt engineering ==========================================================
# Demo on one question across the 3 prompts
demo_qidx = 1  # recursion
demo_rows = responses[responses["question_idx"] == demo_qidx].set_index("prompt_name").reindex(PROMPT_ORDER)

p = rewrite(find("Інженерія запитів:"),
         label="Інженерія запитів:",
         text="складено 3 варіанти системного промпту (від базового до структурованого) і прогнано на "
         f"5 тестових питаннях з курсу інформатики. Нижче - приклад для одного питання "
         f"(Q{demo_qidx + 1}: '{TEST_QUESTIONS[demo_qidx]}'). Повні відповіді на всі 5 питань x 3 "
         "промпти збережено у Results/responses.xlsx.")
cur = Cursor(p)

cur.text(SYSTEM_PROMPTS["basic"], label="Базовий промпт.")
cur.text(shorten(demo_rows.loc["basic", "response"], 500), label="Відповідь:")
cur.text("", align=WD_ALIGN_PARAGRAPH.LEFT)

cur.text(SYSTEM_PROMPTS["improved_v1"], label="Покращений v1 (роль + аудиторія).")
cur.text(shorten(demo_rows.loc["improved_v1", "response"], 500), label="Відповідь:")
cur.text("", align=WD_ALIGN_PARAGRAPH.LEFT)

cur.text(SYSTEM_PROMPTS["improved_v2"], label="Покращений v2 (роль + формат + стиль).")
cur.text(shorten(demo_rows.loc["improved_v2", "response"], 500), label="Відповідь:")

# Table 1: summary per variant (chars/words/latency)
rows = [["Варіант промпту", "Середня довжина, символи", "Середня довжина, слова", "Час/запит, с"]]
for p_name in PROMPT_ORDER:
    rows.append([
        PROMPT_LABEL_UK[p_name],
        f"{int(agg.loc[p_name, 'chars'])}",
        f"{int(agg.loc[p_name, 'words'])}",
        num(agg.loc[p_name, "latency_s"], 1),
    ])
cur.table("Таблиця 1 - Довжина та швидкість генерації по варіантах промпту", rows,
          [6.0, 3.6, 3.0, 2.4])

# Pick best
best_prompt = agg["judge_avg" if "judge_avg" in agg.columns else "judge_relevance"].idxmax()
cur.text(f"у нашому прогоні на Qwen 0.5B найвищу середню judge-оцінку отримав варіант "
         f"'{PROMPT_LABEL_UK[best_prompt]}'. Проте v2 з жорстким форматом часом «ламав» відповідь "
         "цієї малої моделі (див. нижче). При запуску того самого коду з Gemini у Colab варіант v2 "
         "очікується кращим за v1. Детальні числа - у секції Оцінка якості відповідей LLM.",
         label="Вибір найкращого формату:")

# ===== Оцінка якості відповідей LLM ================================================
anchor = rewrite(find("Обґрунтування вибору"),
                 label="Обґрунтування вибору критеріїв і способів оцінювання.",
                 text="для системи використано 3 критерії і 2 способи оцінювання.")
cur = Cursor(anchor)
cur.text("наскільки відповідь по суті питання. Виміряно вручну (judge 1..5) і автоматично "
         "(kw_coverage - частка очікуваних ключових термінів у відповіді).",
         label="Критерій 1. RELEVANCE (релевантність):")
cur.text("наскільки повно розкрито тему: визначення + приклад + нюанси. Оцінка judge 1..5 плюс "
         "евристика structure (0..3): наявність визначення, прикладу, поради.",
         label="Критерій 2. COMPLETENESS (повнота):")
cur.text("наскільки зрозуміло для студента 2 курсу, добра структура, без жаргону. Оцінка judge "
         "1..5.",
         label="Критерій 3. CLARITY (ясність):")

cur.text("окремий промпт до тієї самої LLM, у якому вона виступає як викладач-рецензент і "
         "виставляє 3 цілі оцінки 1..5. Промпт judge:",
         label="Спосіб 1. LLM-as-judge:")
cur.code([JUDGE_PROMPT])
cur.text("три числові показники, що рахуються з тексту без LLM: kw_coverage (ключові слова), "
         "structure (3-частинна структура), довжина (символи/слова) і latency (сек). Усе це дає "
         "об'єктивний базис і страхує від упередженості judge.",
         label="Спосіб 2. Автоматичні евристики:")

# Results table (per prompt variant)
rows = [["Варіант промпту", "Relevance (judge)", "Completeness (judge)", "Clarity (judge)",
         "Judge avg", "KW coverage", "Structure (0..3)"]]
for p_name in PROMPT_ORDER:
    r = agg.loc[p_name]
    rows.append([
        PROMPT_LABEL_UK[p_name],
        num(r["judge_relevance"]),
        num(r["judge_completeness"]),
        num(r["judge_clarity"]),
        num(r.get("judge_avg", (r["judge_relevance"] + r["judge_completeness"] + r["judge_clarity"]) / 3)),
        num(r["kw_coverage"]),
        num(r["structure_0to3"]),
    ])

# Results
anchor2 = rewrite(find("Результати оцінювання"),
                  label="Результати оцінювання.",
                  text="усереднено по 5 тестових питаннях, судить та сама модель, що і відповідає "
          "(single-model LLM-as-judge). Повні сирі оцінки по кожному питанню - у "
          "Results/evaluation.xlsx.")
cur2 = Cursor(anchor2)
cur2.table("Таблиця 2 - Середні оцінки по 3 критеріях і 2 способах", rows,
           [4.4, 2.1, 2.5, 2.0, 1.6, 1.8, 2.0], size=10)
cur2.picture(RESULTS / "research_scores.png", 16,
             "Рисунок 1 - Judge-оцінки за критеріями та нормалізовані евристики")

# Висновки Оцінка
anchor3 = rewrite(find("Висновки про якість відповідей"),
                  label="Висновки про якість відповідей.",
                  text=None)
cur3 = Cursor(anchor3)
basic_j = agg.loc["basic", "judge_avg" if "judge_avg" in agg.columns
                  else "judge_relevance"]
best_j = agg.loc[best_prompt, "judge_avg" if "judge_avg" in agg.columns
                 else "judge_relevance"]
cur3.text(
    f"промпт помітно впливає на всі метрики, але не завжди лінійно: v1 ({num(agg.loc['improved_v1', 'judge_avg'])}) "
    f"> базовий ({num(agg.loc['basic', 'judge_avg'])}) > v2 ({num(agg.loc['improved_v2', 'judge_avg'])}). "
    "На малій моделі Qwen 0.5B занадто жорсткий формат (v2) подекуди ламає відповідь (модель "
    "відмовляється відповідати або видає обрізаний текст), тому v2 програє v1. Крім промпту, на "
    "якість впливає розмір моделі (у Colab з Gemini цифри вищі і v2 має перемагати), складність "
    "питання і параметри генерації (temperature, max_tokens).",
    label="Основне спостереження:")
cur3.text(
    "LLM-as-judge чутливий до самої моделі (single-model bias), тому підтверджуємо його "
    "незалежними евристиками. Якщо запустити з Gemini у Colab, абсолютні оцінки будуть вищі, "
    "а розрив між v1 і v2 - меншим або оберненим.",
    label="Обмеження методу:")

# ===== Задача дослідження =========================================================
fill(find("Задача дослідження"))

anchor = rewrite(find("Дослідити вказаний фактор"),
                 label="Дослідити вказаний фактор.",
                 text=None)
cur = Cursor(anchor)
cur.text("за варіантом 2 досліджено вплив інженерії запитів (prompt engineering) на якість "
         "відповідей LLM. План експерименту такий. 1) Фіксуємо модель, температуру=0, "
         "max_tokens=300 і набір з 5 тестових питань з курсу інформатики. "
         "2) Варіюємо тільки системний промпт у 3 конфігураціях (basic -> role+audience -> "
         "role+format+style). 3) На кожну пару (промпт x питання) генеруємо відповідь. "
         "4) Оцінюємо через LLM-as-judge і через 3 автоматичні метрики. "
         "5) Порівнюємо середні оцінки.",
         label="План експерименту:")

anchor = rewrite(find("Навести результати дослідження"),
                 label="Навести результати дослідження.",
                 text=None)
cur = Cursor(anchor)
cur.text("ключові результати - в табл. 2 і на рис. 1. Нижче наведено ту саму judge-оцінку в "
         "розрізі окремих питань, щоб побачити, чи це загальна тенденція, чи лише усереднення.")
cur.picture(RESULTS / "research_per_question.png", 16,
            "Рисунок 2 - Judge-оцінки на кожне з 5 тестових питань, по 3 промптах")

# Conclusions
anchor = rewrite(find("Висновки за результатами дослідження:"),
                 label="Висновки за результатами дослідження.",
                 text=None)
cur = Cursor(anchor)
cur.text(
    f"інженерія промпту помітно впливає на всі метрики. Середня judge-оцінка: базовий "
    f"{num(agg.loc['basic', 'judge_avg'])}, v1 {num(agg.loc['improved_v1', 'judge_avg'])}, "
    f"v2 {num(agg.loc['improved_v2', 'judge_avg'])}. Евристики - у табл. 2.",
    label="1. Так, промпт справді впливає:")
cur.text(
    "варіант v1 (додана роль + аудиторія) дав найкращий результат на цій моделі - модель "
    "орієнтується, кому відповідає, і спрощує мову, зберігаючи при цьому розгорнутість. "
    "Абсолютна judge-оцінка саме у v1 найвища.",
    label="2. v1 переміг у нашому прогоні:")
cur.text(
    "варіант v2 (жорсткий 3-частинний формат) на малій моделі Qwen 0.5B дав ГІРШИЙ результат, "
    "ніж v1 і навіть базовий. Причина: мала модель не завжди справляється з виконанням "
    "структурних вимог і подекуди відмовляється відповідати або видає обрізаний текст (див. Q3 "
    "в evaluation.xlsx). Це важливий практичний висновок: занадто складний промпт може "
    "«завалити» слабку модель. У той же час структурний бал (structure_0to3) у v2 на окремих "
    "питаннях вищий, тобто там, де модель виконала інструкцію, формат допоміг.",
    label="3. Складний формат може зашкодити на малій моделі:")
cur.text(
    "у Colab з Gemini (той самий код і промпти) очікується інша картина: сильніша модель краще "
    "виконує жорсткі інструкції формату, тому v2 має обганяти і v1, і базовий. Отже, оптимальний "
    "промпт залежить від потужності моделі - це головне практичне спостереження.",
    label="4. Залежність від моделі:")
cur.text(
    "теоретичні рекомендації (specify role, audience, format) підтвердились частково: роль і "
    "аудиторія дали стабільний приріст у всіх випадках, формат - тільки на сильніших моделях. "
    "Отже, інженерія промпту повинна враховувати можливості конкретної LLM.",
    label="5. Відповідність очікуванням:")

# Remove "Обсяг" note
note = find("Обсяг")._p
while (prev := note.getprevious()) is not None and prev.tag.endswith("}p") and not "".join(prev.itertext()).strip():
    prev.getparent().remove(prev)
note.getparent().remove(note)

doc.save(OUT)
print("saved", OUT)
