"""LLM wrapper for KP5 variant 2.

Supports two back-ends:
- 'gemini': google-generativeai, needs GOOGLE_API_KEY env var; model is gemini-1.5-flash by default.
- 'qwen':   HuggingFace Qwen/Qwen2.5-0.5B-Instruct, runs on CPU, no internet needed after download.

The qwen back-end is used by default so the whole project runs offline on CPU for the report.
In Colab (or whenever a key is available) switch to gemini by passing backend='gemini'.
"""
import os
import time
from pathlib import Path

os.environ.pop("HF_TOKEN", None)
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"

DEFAULT_QWEN_MODEL = "Qwen/Qwen2.5-0.5B-Instruct"
DEFAULT_GEMINI_MODEL = "gemini-1.5-flash"


class LLM:
    def __init__(self, backend="qwen", model_name=None, seed=42):
        self.backend = backend
        self.seed = seed
        if backend == "qwen":
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
            self.torch = torch
            name = model_name or DEFAULT_QWEN_MODEL
            print(f"loading {name}...")
            t0 = time.perf_counter()
            self.tok = AutoTokenizer.from_pretrained(name)
            self.model = AutoModelForCausalLM.from_pretrained(name, dtype=torch.float32)
            self.model.eval()
            self.model_name = name
            self.n_params = sum(p.numel() for p in self.model.parameters())
            print(f"  loaded in {time.perf_counter() - t0:.1f} s, {self.n_params / 1e6:.1f}M params")
        elif backend == "gemini":
            import google.generativeai as genai
            key = os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")
            if not key:
                raise RuntimeError("set GOOGLE_API_KEY env var for Gemini backend")
            genai.configure(api_key=key)
            self.model_name = model_name or DEFAULT_GEMINI_MODEL
            self.client = genai.GenerativeModel(self.model_name)
            self.n_params = None  # not disclosed by Google
        else:
            raise ValueError(backend)

    def generate(self, system_prompt, user_prompt, max_new_tokens=256, temperature=0.0):
        """Returns (reply_text, latency_seconds)."""
        if self.backend == "qwen":
            msgs = [{"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}]
            prompt = self.tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
            tokens = self.tok(prompt, return_tensors="pt")
            self.torch.manual_seed(self.seed)
            t0 = time.perf_counter()
            with self.torch.no_grad():
                out = self.model.generate(
                    **tokens,
                    max_new_tokens=max_new_tokens,
                    do_sample=temperature > 0,
                    temperature=max(temperature, 1e-6),
                    pad_token_id=self.tok.eos_token_id,
                )
            dt = time.perf_counter() - t0
            text = self.tok.decode(out[0][tokens.input_ids.shape[1]:], skip_special_tokens=True)
            return text.strip(), dt
        else:
            full = f"{system_prompt}\n\n---\n\nПитання: {user_prompt}"
            t0 = time.perf_counter()
            resp = self.client.generate_content(
                full,
                generation_config={"temperature": temperature,
                                   "max_output_tokens": max_new_tokens})
            dt = time.perf_counter() - t0
            return (resp.text or "").strip(), dt


def default_llm():
    """Pick Gemini if API key is set, otherwise Qwen."""
    if os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY"):
        try:
            return LLM(backend="gemini")
        except Exception as e:
            print(f"Gemini backend failed ({e}); falling back to Qwen")
    return LLM(backend="qwen")


if __name__ == "__main__":
    llm = default_llm()
    text, dt = llm.generate(
        "Ти освітній помічник для студентів інформатики. Відповідай коротко і по суті.",
        "Що таке рекурсія?", max_new_tokens=150)
    print(f"\n[{llm.backend} / {llm.model_name}, {dt:.1f} s]\n{text}")
