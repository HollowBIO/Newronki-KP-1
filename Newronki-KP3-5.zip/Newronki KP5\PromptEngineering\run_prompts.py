"""Generate responses for 3 prompt variants x 5 test questions.

Saves everything to Results/responses.json and a tidy xlsx.
"""
import json
import sys
from pathlib import Path

import pandas as pd

KP5_DIR = Path(__file__).resolve().parent.parent
RESULTS_DIR = KP5_DIR / "Results"
RESULTS_DIR.mkdir(exist_ok=True)
sys.path.insert(0, str(KP5_DIR / "BotCore"))
from bot import default_llm  # noqa: E402
from prompts import SYSTEM_PROMPTS, PROMPT_ORDER, TEST_QUESTIONS  # noqa: E402


def main():
    llm = default_llm()
    rows = []
    for pname in PROMPT_ORDER:
        sysp = SYSTEM_PROMPTS[pname]
        for qi, q in enumerate(TEST_QUESTIONS):
            print(f"\n[{pname} / Q{qi + 1}] {q}")
            text, dt = llm.generate(sysp, q, max_new_tokens=300, temperature=0.0)
            print(f"  ({dt:.1f} s, {len(text)} chars)")
            print(" ", text[:200].replace("\n", " "), "...")
            rows.append({
                "prompt_name": pname,
                "question_idx": qi,
                "question": q,
                "response": text,
                "latency_s": dt,
                "chars": len(text),
                "words": len(text.split()),
                "backend": llm.backend,
                "model": llm.model_name,
            })
    df = pd.DataFrame(rows)
    df.to_excel(RESULTS_DIR / "responses.xlsx", index=False)
    with open(RESULTS_DIR / "responses.json", "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print("\nsaved", RESULTS_DIR / "responses.xlsx")


if __name__ == "__main__":
    main()
