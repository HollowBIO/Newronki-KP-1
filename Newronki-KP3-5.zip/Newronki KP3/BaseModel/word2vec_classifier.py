"""Word2Vec embeddings + simple classifier for IMDB.

Trains Word2Vec on the train split, builds an embedding matrix,
then trains an Embedding (frozen W2V) -> GlobalAveragePooling1D -> Dense -> Dense model.
"""
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import tensorflow as tf
from gensim.models import Word2Vec
from sklearn.metrics import classification_report, confusion_matrix
from tensorflow import keras

KP3_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = KP3_DIR / "Data"
RESULTS_DIR = KP3_DIR / "Results"
RESULTS_DIR.mkdir(exist_ok=True)
sys.path.insert(0, str(DATA_DIR))
from prepare_imdb import load, VOCAB_SIZE, MAX_LEN, SEED  # noqa: E402

EMBEDDING_DIM = 100
BATCH_SIZE = 64
EPOCHS = 10

keras.utils.set_random_seed(SEED)

# --- 1. Load the already padded IMDB -------------------------------------------------
x_train, y_train, x_test, y_test = load()
print(f"train: {x_train.shape}, test: {x_test.shape}")

# --- 2. Train Word2Vec on train sentences --------------------------------------------
w2v_path = RESULTS_DIR / "word2vec.model"
sentences_path = DATA_DIR / "imdb_train_tokens.txt"

print("training Word2Vec...")
t0 = time.perf_counter()
with open(sentences_path, encoding="utf-8") as f:
    sentences = [line.split() for line in f]
w2v = Word2Vec(sentences, vector_size=EMBEDDING_DIM, window=5, min_count=1,
               workers=4, sg=1, epochs=5, seed=SEED)
w2v.save(str(w2v_path))
print(f"Word2Vec done in {time.perf_counter() - t0:.1f} s, "
      f"vocab {len(w2v.wv):,} words")

# --- 3. Build the embedding matrix in Keras index space ------------------------------
word_index = keras.datasets.imdb.get_word_index()
embedding_matrix = np.zeros((VOCAB_SIZE, EMBEDDING_DIM), dtype=np.float32)
hits = 0
for word, idx in word_index.items():
    i = idx + 3  # Keras offsets
    if i >= VOCAB_SIZE:
        continue
    if word in w2v.wv:
        embedding_matrix[i] = w2v.wv[word]
        hits += 1
print(f"filled {hits:,} of {VOCAB_SIZE:,} embedding rows from Word2Vec")

# --- 4. Simple classifier on top of frozen Word2Vec ----------------------------------
model = keras.Sequential([
    keras.layers.Input(shape=(MAX_LEN,)),
    keras.layers.Embedding(VOCAB_SIZE, EMBEDDING_DIM,
                           embeddings_initializer=keras.initializers.Constant(embedding_matrix),
                           mask_zero=True, trainable=False),
    keras.layers.GlobalAveragePooling1D(),
    keras.layers.Dense(32, activation="relu"),
    keras.layers.Dense(1, activation="sigmoid"),
])
model.summary()
model.compile(optimizer=keras.optimizers.Adam(1e-3),
              loss="binary_crossentropy", metrics=["accuracy"])


class EpochTimer(keras.callbacks.Callback):
    def on_train_begin(self, logs=None):
        self.times = []

    def on_epoch_begin(self, epoch, logs=None):
        self.start = time.perf_counter()

    def on_epoch_end(self, epoch, logs=None):
        self.times.append(time.perf_counter() - self.start)


timer = EpochTimer()
early_stop = keras.callbacks.EarlyStopping(monitor="val_loss", patience=3,
                                           restore_best_weights=True)
checkpoint = keras.callbacks.ModelCheckpoint(
    RESULTS_DIR / "base_classifier.keras", monitor="val_loss", save_best_only=True)

history = model.fit(
    x_train, y_train,
    validation_split=0.2,
    batch_size=BATCH_SIZE, epochs=EPOCHS,
    callbacks=[early_stop, checkpoint, timer],
    verbose=2,
)

epochs_df = pd.DataFrame(history.history)
epochs_df["epoch_time_s"] = timer.times
epochs_df.index.name = "epoch"
epochs_df.to_excel(RESULTS_DIR / "base_classifier_epochs.xlsx")

# --- 5. Test evaluation --------------------------------------------------------------
test_loss, test_acc = model.evaluate(x_test, y_test, verbose=0)
y_pred = (model.predict(x_test, verbose=0) > 0.5).astype(int).ravel()
print(f"\nTEST  loss {test_loss:.4f}  acc {test_acc:.4f}")
print(classification_report(y_test, y_pred, digits=4))
print("confusion matrix:")
print(confusion_matrix(y_test, y_pred))

best = epochs_df["val_loss"].idxmin()
summary = pd.Series({
    "model": "word2vec+pool+dense",
    "params": int(np.sum([np.prod(w.shape) for w in model.trainable_weights])),
    "epochs_trained": len(epochs_df),
    "best_epoch": best,
    "epoch_time_s_median": float(epochs_df["epoch_time_s"].median()),
    "train_acc": float(epochs_df.loc[best, "accuracy"]),
    "val_acc": float(epochs_df.loc[best, "val_accuracy"]),
    "val_loss": float(epochs_df.loc[best, "val_loss"]),
    "test_acc": float(test_acc),
    "test_loss": float(test_loss),
})
summary.to_frame("value").to_excel(RESULTS_DIR / "base_classifier_test.xlsx")
print(summary)
