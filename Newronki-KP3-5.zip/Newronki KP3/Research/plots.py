"""Generate plots for the research results and the base models."""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

KP3_DIR = Path(__file__).resolve().parent.parent
RESULTS = KP3_DIR / "Results"
RESEARCH = RESULTS / "research"
RESEARCH.mkdir(parents=True, exist_ok=True)

VARIANTS = ["units_32", "units_64", "units_128", "dropout_05", "bidirectional"]
VARIANT_LABEL = {
    "units_32": "units=32",
    "units_64": "units=64 (base)",
    "units_128": "units=128",
    "dropout_05": "dropout=0.5",
    "bidirectional": "bidirectional",
}


def _history_plot(name, path, title):
    df = pd.read_excel(path, index_col="epoch")
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.4))
    ax[0].plot(df.index, df["loss"], label="train")
    ax[0].plot(df.index, df["val_loss"], label="val")
    ax[0].set_title(f"{title} — loss"); ax[0].set_xlabel("epoch"); ax[0].legend(); ax[0].grid(alpha=0.3)
    ax[1].plot(df.index, df["accuracy"], label="train")
    ax[1].plot(df.index, df["val_accuracy"], label="val")
    ax[1].set_title(f"{title} — accuracy"); ax[1].set_xlabel("epoch"); ax[1].legend(); ax[1].grid(alpha=0.3)
    plt.tight_layout()
    out = RESULTS / f"{name}_history.png"
    plt.savefig(out, dpi=120); plt.close()
    print("saved", out)


def main():
    if (RESULTS / "base_classifier_epochs.xlsx").exists():
        _history_plot("base_classifier", RESULTS / "base_classifier_epochs.xlsx",
                      "Word2Vec + Dense")
    if (RESULTS / "lstm_base_epochs.xlsx").exists():
        _history_plot("lstm_base", RESULTS / "lstm_base_epochs.xlsx", "LSTM-base")

    # Research summary bars
    summary_path = RESEARCH / "summary.xlsx"
    if summary_path.exists():
        s = pd.read_excel(summary_path).set_index("variant").reindex(VARIANTS)
        labels = [VARIANT_LABEL[v] for v in s.index]
        fig, ax = plt.subplots(1, 2, figsize=(12, 3.6))
        bars = ax[0].bar(labels, s["test_acc"] * 100)
        ax[0].set_ylabel("test accuracy, %")
        ax[0].set_ylim(75, s["test_acc"].max() * 100 + 3)
        ax[0].tick_params(axis="x", rotation=25)
        ax[0].grid(axis="y", alpha=0.3)
        for b, v in zip(bars, s["test_acc"]):
            ax[0].text(b.get_x() + b.get_width() / 2, v * 100 + 0.1, f"{v*100:.1f}",
                       ha="center", va="bottom", fontsize=9)
        ax[1].bar(labels, s["epoch_time_s"], color="orange")
        ax[1].set_ylabel("median epoch time, s")
        ax[1].tick_params(axis="x", rotation=25)
        ax[1].grid(axis="y", alpha=0.3)
        plt.tight_layout()
        plt.savefig(RESEARCH / "research_accuracy_time.png", dpi=120)
        plt.close()
        print("saved", RESEARCH / "research_accuracy_time.png")

    # Research per-variant val loss curves
    fig, ax = plt.subplots(figsize=(9, 4))
    for v in VARIANTS:
        f = RESEARCH / f"{v}_epochs.xlsx"
        if f.exists():
            d = pd.read_excel(f, index_col="epoch")
            ax.plot(d.index, d["val_loss"], marker="o", label=VARIANT_LABEL[v])
    ax.set_xlabel("epoch"); ax.set_ylabel("val loss"); ax.set_title("Validation loss by LSTM variant")
    ax.legend(); ax.grid(alpha=0.3); plt.tight_layout()
    plt.savefig(RESEARCH / "research_val_loss.png", dpi=120); plt.close()
    print("saved", RESEARCH / "research_val_loss.png")


if __name__ == "__main__":
    main()
