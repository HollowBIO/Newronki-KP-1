"""Research of LSTM-layer parameters for variant 2.

Keeps everything else fixed (Embedding(dim=64), Adam 1e-3, batch 64, patience=2, seed=42),
only the LSTM layer is varied.
"""
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score
from tensorflow import keras

KP3_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = KP3_DIR / "Data"
RESULTS_DIR = KP3_DIR / "Results" / "research"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(DATA_DIR))
from prepare_imdb import load, VOCAB_SIZE, MAX_LEN, SEED  # noqa: E402

EMBEDDING_DIM = 64
BATCH_SIZE = 64
EPOCHS = 6


def build_variant(name):
    """Build a model per variant name."""
    inp = keras.Input(shape=(MAX_LEN,))
    x = keras.layers.Embedding(VOCAB_SIZE, EMBEDDING_DIM, mask_zero=True)(inp)
    if name == "units_32":
        x = keras.layers.LSTM(32)(x)
    elif name == "units_64":  # base
        x = keras.layers.LSTM(64)(x)
    elif name == "units_128":
        x = keras.layers.LSTM(128)(x)
    elif name == "dropout_05":
        x = keras.layers.LSTM(64, dropout=0.5)(x)
    elif name == "bidirectional":
        x = keras.layers.Bidirectional(keras.layers.LSTM(64))(x)
    else:
        raise ValueError(name)
    out = keras.layers.Dense(1, activation="sigmoid")(x)
    return keras.Model(inp, out, name=name)


class EpochTimer(keras.callbacks.Callback):
    def on_train_begin(self, logs=None):
        self.times = []

    def on_epoch_begin(self, epoch, logs=None):
        self.start = time.perf_counter()

    def on_epoch_end(self, epoch, logs=None):
        self.times.append(time.perf_counter() - self.start)


def run(name, x_train, y_train, x_test, y_test):
    keras.utils.set_random_seed(SEED)
    model = build_variant(name)
    model.compile(optimizer=keras.optimizers.Adam(1e-3),
                  loss="binary_crossentropy", metrics=["accuracy"])

    timer = EpochTimer()
    hist = model.fit(
        x_train, y_train,
        validation_split=0.2,
        batch_size=BATCH_SIZE, epochs=EPOCHS,
        callbacks=[
            keras.callbacks.EarlyStopping(monitor="val_loss", patience=2, restore_best_weights=True),
            timer,
        ],
        verbose=2,
    )
    df = pd.DataFrame(hist.history)
    df["epoch_time_s"] = timer.times
    df.index.name = "epoch"
    df.to_excel(RESULTS_DIR / f"{name}_epochs.xlsx")

    test_loss, test_acc = model.evaluate(x_test, y_test, verbose=0)
    y_pred = (model.predict(x_test, verbose=0) > 0.5).astype(int).ravel()
    f1 = f1_score(y_test, y_pred, average="macro")
    best = df["val_loss"].idxmin()
    params = int(np.sum([np.prod(w.shape) for w in model.trainable_weights]))
    print(f"\n[{name}] params {params:,}  epochs {len(df)}  "
          f"best {best}  epoch_time {df['epoch_time_s'].median():.1f}s  "
          f"val_acc {df.loc[best, 'val_accuracy']:.4f}  "
          f"test_acc {test_acc:.4f}  test_loss {test_loss:.4f}  F1 {f1:.4f}")
    return {
        "variant": name,
        "params": params,
        "epochs": len(df),
        "best_epoch": int(best),
        "epoch_time_s": float(df["epoch_time_s"].median()),
        "train_acc": float(df.loc[best, "accuracy"]),
        "val_acc": float(df.loc[best, "val_accuracy"]),
        "val_loss": float(df.loc[best, "val_loss"]),
        "test_acc": float(test_acc),
        "test_loss": float(test_loss),
        "test_macro_f1": float(f1),
    }


if __name__ == "__main__":
    x_train, y_train, x_test, y_test = load()
    names = ["units_32", "units_64", "units_128", "dropout_05", "bidirectional"]
    if len(sys.argv) > 1 and sys.argv[1] != "all":
        names = sys.argv[1:]

    rows = []
    for name in names:
        rows.append(run(name, x_train, y_train, x_test, y_test))
    pd.DataFrame(rows).to_excel(RESULTS_DIR / "summary.xlsx", index=False)
    print("\n=== summary ===")
    print(pd.DataFrame(rows).to_string(index=False))
