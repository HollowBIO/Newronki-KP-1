"""Combine per-variant epoch logs + known test metrics into summary.xlsx.

Call this once the research has produced:
- Results/research/<variant>_epochs.xlsx
and we have the test accuracy/loss values from the training log (stdout).
"""
import sys
from pathlib import Path

import pandas as pd

KP3_DIR = Path(__file__).resolve().parent.parent
RES = KP3_DIR / "Results" / "research"

# Hardcoded test metrics captured from the full training run output.
# Fill in bidirectional after it finishes.
KNOWN = {
    "units_32":      {"params": 1_292_449, "test_acc": 0.8358, "test_loss": 0.4180, "test_macro_f1": 0.8350},
    "units_64":      {"params": 1_313_089, "test_acc": 0.8367, "test_loss": 0.3961, "test_macro_f1": 0.8364},
    "units_128":     {"params": 1_378_945, "test_acc": 0.8259, "test_loss": 0.4001, "test_macro_f1": 0.8259},
    "dropout_05":    {"params": 1_313_089, "test_acc": 0.8494, "test_loss": 0.3609, "test_macro_f1": 0.8494},
    "bidirectional": {"params": 1_346_177, "test_acc": 0.8498, "test_loss": 0.3460, "test_macro_f1": 0.8497},
}

VARIANTS = ["units_32", "units_64", "units_128", "dropout_05", "bidirectional"]


def main():
    rows = []
    for name in VARIANTS:
        epochs_path = RES / f"{name}_epochs.xlsx"
        if not epochs_path.exists():
            print(f"skip {name}: no epochs file")
            continue
        df = pd.read_excel(epochs_path, index_col="epoch")
        best = df["val_loss"].idxmin()
        row = {
            "variant": name,
            "params": KNOWN.get(name, {}).get("params"),
            "epochs": len(df),
            "best_epoch": int(best),
            "epoch_time_s": float(df["epoch_time_s"].median()),
            "train_acc": float(df.loc[best, "accuracy"]),
            "val_acc": float(df.loc[best, "val_accuracy"]),
            "val_loss": float(df.loc[best, "val_loss"]),
            "test_acc": KNOWN.get(name, {}).get("test_acc"),
            "test_loss": KNOWN.get(name, {}).get("test_loss"),
            "test_macro_f1": KNOWN.get(name, {}).get("test_macro_f1"),
        }
        rows.append(row)
    pd.DataFrame(rows).to_excel(RES / "summary.xlsx", index=False)
    print(pd.DataFrame(rows).to_string(index=False))


if __name__ == "__main__":
    main()
