# KP3 — session notes (read to resume)

Last updated: 2026-10-14.

## The task

- Course "Нейронні мережі", КП №3 "Нейронні мережі для роботи з текстовими послідовностями".
  Student: **Гладишев Андрій Олексійович, ІК-61мп**.
- **Variant 2:** dataset **IMDB**, RNN **LSTM**, research topic **"Вплив параметрів рекурентного шару"**.
- Task points: (1) prep + Word2Vec+simple classifier; (2) base LSTM; (3) research of LSTM params;
  (4) fine-tune a transformer (DistilBERT); (5) report in Ukrainian (3-6 pages).

## Status

- [x] IMDB prep (`Data/prepare_imdb.py`): 25k/25k, 20k vocab, maxlen 200.
- [x] Word2Vec + Dense (`BaseModel/word2vec_classifier.py`): test acc 82.6%, 10 epochs @ 3.7s each.
- [x] Base LSTM (`RNNModel/lstm_base.py`): test acc 83.7%, 3 epochs @ 21s each, overfits fast.
- [x] Research (`Research/lstm_variants.py`): 5 variants done.
      units_32 / units_64 (base) / units_128 / dropout_05 / bidirectional. Summary + plots in `Results/research/`.
- [x] DistilBERT (`TransferModel/distilbert_classifier.py`): subset run on CPU; use GPU in Colab for full set.
- [x] Report (`Report/build_report.py`) — fills the KP3 template with real numbers.
- [x] Colab notebook (`KP3_colab.ipynb`) — end-to-end, same code structure.

## Key results

| Model                      | Params         | Test acc | Test loss | Notes |
|---|---|---|---|---|
| Word2Vec + GAP + Dense     | 3,265 trainable (2M frozen) | 82.6% | 0.388 | no overfit, maybe slight underfit |
| LSTM(64)                   | 1,313,089      | 83.7%    | 0.396    | overfits by epoch 2 |
| LSTM units=32              | 1,292,449      | 83.6%    | 0.418    | similar to base |
| LSTM units=128             | 1,378,945      | 82.6%    | 0.400    | more overfit, slower |
| LSTM dropout=0.5           | 1,313,089      | **84.9%**| 0.361    | best among plain LSTMs |
| LSTM bidirectional         | 1,346,177      | **85.0%**| 0.346    | best overall LSTM; slow |
| DistilBERT pretrained-only | 66M            | ~50%     | 0.69     | random (new head)   |
| DistilBERT fine-tuned      | 66M            | ~88%*    | ~0.3*    | *subset on CPU; full set on GPU → 92-93% |

## Running order

```bash
pip install -r "Newronki KP3/requirements.txt"
pip install "transformers<5" tf-keras   # for TF-flavored HuggingFace models

python "Newronki KP3/Data/prepare_imdb.py"
python "Newronki KP3/BaseModel/word2vec_classifier.py"
python "Newronki KP3/RNNModel/lstm_base.py"
python "Newronki KP3/Research/lstm_variants.py" all
python "Newronki KP3/Research/make_summary_from_logs.py"   # or re-run lstm_variants.py from scratch
python "Newronki KP3/Research/plots.py"
TRAIN_SUBSET=5000 TEST_SUBSET=2000 EPOCHS=2 BATCH_SIZE=16 \
    python "Newronki KP3/TransferModel/distilbert_classifier.py"
python "Newronki KP3/Report/build_report.py"
```

Or the lazy option: upload `KP3_colab.ipynb` to Google Colab, pick T4 GPU, run all cells.

## Decisions and user preferences

- Student-style, informal Ukrainian text; comma as decimal separator; "%" (not п. п.) for diffs.
- Report mirrors KP2's structure (bold labels, Table Grid, Courier New code).
- `recurrent_dropout_03` dropped from the research — on CPU it falls off CuDNN and takes forever;
  5 variants are enough.
- Early stopping with `patience=2` for LSTM, `patience=3` for the GAP classifier.
- Transformer: full HF Transformers API with `TFDistilBertForSequenceClassification`;
  `transformers<5` and `tf-keras` are required for the Keras 3 setup here.
- Everything deterministic with `seed=42` where possible.

## Known gotchas

- `transformers` 5.x removed TF model support — install `transformers<5`.
- Keras 3 + Transformers wants `pip install tf-keras` alongside.
- `oneDNN` warnings about numerical drift are harmless; set `TF_ENABLE_ONEDNN_OPTS=0` to silence.
- `recurrent_dropout=0.3` kills CuDNN and makes an LSTM epoch 3-5× slower.
- Report rebuild overwrites the .docx (backup is kept as `*.backup.docx`); edit `build_report.py`, not Word.
