"""Prepares IMDB for the whole KP3 pipeline.

Saves a single .npz with padded int-encoded sequences for the Keras pipeline,
and a .txt of raw tokenised sentences for Word2Vec.
"""
import re
from pathlib import Path

import numpy as np
from tensorflow import keras

KP3_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = KP3_DIR / "Data"
RESULTS_DIR = KP3_DIR / "Results"
RESULTS_DIR.mkdir(exist_ok=True)

VOCAB_SIZE = 20000  # keeps the 20k most common words
MAX_LEN = 200       # cuts/pads reviews to 200 tokens
SEED = 42


def _save():
    (x_train, y_train), (x_test, y_test) = keras.datasets.imdb.load_data(
        num_words=VOCAB_SIZE, seed=SEED)

    # Pad/truncate so every review has the same length
    x_train = keras.utils.pad_sequences(x_train, maxlen=MAX_LEN, padding="post", truncating="post")
    x_test = keras.utils.pad_sequences(x_test, maxlen=MAX_LEN, padding="post", truncating="post")

    np.savez_compressed(DATA_DIR / "imdb_padded.npz",
                        x_train=x_train, y_train=y_train, x_test=x_test, y_test=y_test)

    # Build the word->index dict and dump the inverse (needed for Word2Vec vocabulary)
    word_index = keras.datasets.imdb.get_word_index()
    # Keras adds 3 reserved offsets: 0=pad, 1=start, 2=oov
    index_word = {i + 3: w for w, i in word_index.items()}
    index_word[0] = "<pad>"
    index_word[1] = "<start>"
    index_word[2] = "<oov>"

    # Save tokenised train sentences for Word2Vec, one review per line
    with open(DATA_DIR / "imdb_train_tokens.txt", "w", encoding="utf-8") as f:
        for seq in x_train:
            tokens = [index_word.get(i, "<oov>") for i in seq if i != 0]
            f.write(" ".join(tokens) + "\n")

    return x_train, y_train, x_test, y_test


def load():
    """Returns (x_train, y_train, x_test, y_test) from the saved .npz."""
    path = DATA_DIR / "imdb_padded.npz"
    if not path.exists():
        _save()
    data = np.load(path)
    return data["x_train"], data["y_train"], data["x_test"], data["y_test"]


if __name__ == "__main__":
    x_train, y_train, x_test, y_test = _save()
    print(f"train: {x_train.shape}, labels mean = {y_train.mean():.3f}")
    print(f"test:  {x_test.shape}, labels mean = {y_test.mean():.3f}")
    # Word count stats
    non_pad_lens = (x_train != 0).sum(axis=1)
    print(f"non-pad tokens per review (train): min={non_pad_lens.min()}, "
          f"mean={non_pad_lens.mean():.1f}, max={non_pad_lens.max()}")
    print(f"saved to {DATA_DIR}")
