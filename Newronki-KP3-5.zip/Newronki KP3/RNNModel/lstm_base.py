"""Base LSTM for IMDB (variant 2).

Trainable Embedding -> LSTM(64) -> Dense(1, sigmoid).
"""
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import classification_report, confusion_matrix
from tensorflow import keras

KP3_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = KP3_DIR / "Data"
RESULTS_DIR = KP3_DIR / "Results"
sys.path.insert(0, str(DATA_DIR))
from prepare_imdb import load, VOCAB_SIZE, MAX_LEN, SEED  # noqa: E402

EMBEDDING_DIM = 64
LSTM_UNITS = 64
BATCH_SIZE = 64
EPOCHS = 8

keras.utils.set_random_seed(SEED)

x_train, y_train, x_test, y_test = load()

model = keras.Sequential([
    keras.layers.Input(shape=(MAX_LEN,)),
    keras.layers.Embedding(VOCAB_SIZE, EMBEDDING_DIM, mask_zero=True),
    keras.layers.LSTM(LSTM_UNITS),
    keras.layers.Dense(1, activation="sigmoid"),
])
model.summary()
model.compile(optimizer=keras.optimizers.Adam(1e-3),
              loss="binary_crossentropy", metrics=["accuracy"])


class EpochTimer(keras.callbacks.Callback):
    def on_train_begin(self, logs=None):
        self.times = []

    def on_epoch_begin(self, epoch, logs=None):
        self.start = time.perf_counter()

    def on_epoch_end(self, epoch, logs=None):
        self.times.append(time.perf_counter() - self.start)


timer = EpochTimer()
early_stop = keras.callbacks.EarlyStopping(monitor="val_loss", patience=2, restore_best_weights=True)
checkpoint = keras.callbacks.ModelCheckpoint(
    RESULTS_DIR / "lstm_base.keras", monitor="val_loss", save_best_only=True)

history = model.fit(
    x_train, y_train,
    validation_split=0.2,
    batch_size=BATCH_SIZE, epochs=EPOCHS,
    callbacks=[early_stop, checkpoint, timer],
    verbose=2,
)

epochs_df = pd.DataFrame(history.history)
epochs_df["epoch_time_s"] = timer.times
epochs_df.index.name = "epoch"
epochs_df.to_excel(RESULTS_DIR / "lstm_base_epochs.xlsx")

test_loss, test_acc = model.evaluate(x_test, y_test, verbose=0)
y_pred = (model.predict(x_test, verbose=0) > 0.5).astype(int).ravel()
print(f"\nTEST  loss {test_loss:.4f}  acc {test_acc:.4f}")
print(classification_report(y_test, y_pred, digits=4))
print("confusion matrix:")
print(confusion_matrix(y_test, y_pred))

best = epochs_df["val_loss"].idxmin()
summary = pd.Series({
    "model": "LSTM-base",
    "params": int(np.sum([np.prod(w.shape) for w in model.trainable_weights])),
    "epochs_trained": len(epochs_df),
    "best_epoch": best,
    "epoch_time_s_median": float(epochs_df["epoch_time_s"].median()),
    "train_acc": float(epochs_df.loc[best, "accuracy"]),
    "val_acc": float(epochs_df.loc[best, "val_accuracy"]),
    "val_loss": float(epochs_df.loc[best, "val_loss"]),
    "test_acc": float(test_acc),
    "test_loss": float(test_loss),
})
summary.to_frame("value").to_excel(RESULTS_DIR / "lstm_base_test.xlsx")
print(summary)
