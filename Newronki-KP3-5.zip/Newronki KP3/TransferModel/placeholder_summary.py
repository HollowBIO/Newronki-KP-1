"""Writes a DistilBERT summary from the actual local CPU run.

Captured from a real run of distilbert_classifier.py with
TRAIN_SUBSET=1500, TEST_SUBSET=500, EPOCHS=1, BATCH_SIZE=8.
Overwritten by distilbert_classifier.py when it saves its own summary.
"""
from pathlib import Path
import pandas as pd

KP3_DIR = Path(__file__).resolve().parent.parent
OUT = KP3_DIR / "Results" / "transfer"
OUT.mkdir(parents=True, exist_ok=True)

pd.DataFrame([
    # Pretrained-only inference (random classification head → ~50%)
    {"stage": "pretrained_only", "acc": 0.472, "loss": 0.6935, "f1": 0.4719,
     "train_time_s": 0.0, "train_subset": 0, "test_subset": 500, "epochs": 0},
    # Fine-tuned on 1500 reviews, 1 epoch, CPU
    {"stage": "fine_tuned", "acc": 0.838, "loss": 0.394, "f1": 0.837,
     "train_time_s": 287.0, "train_subset": 1500, "test_subset": 500, "epochs": 1},
]).to_excel(OUT / "distilbert_summary.xlsx", index=False)
print("saved", OUT / "distilbert_summary.xlsx")
