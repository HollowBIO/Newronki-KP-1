"""DistilBERT fine-tuned for IMDB sentiment.

Uses the raw text IMDB from Keras (keras.datasets.imdb.get_word_index + decoding)
and tokenises with the pretrained DistilBERT tokenizer.
"""
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.metrics import classification_report, confusion_matrix, f1_score
from tensorflow import keras
from transformers import DistilBertTokenizerFast, TFDistilBertForSequenceClassification

os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")
# Public model: don't send the (possibly expired) stored HF token with the request
os.environ.pop("HF_TOKEN", None)
os.environ.pop("HUGGING_FACE_HUB_TOKEN", None)
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"

KP3_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = KP3_DIR / "Data"
RESULTS_DIR = KP3_DIR / "Results" / "transfer"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(DATA_DIR))

MODEL_NAME = "distilbert-base-uncased"
MAX_LEN = 128
SEED = 42
# Subset so a run finishes on CPU in a reasonable time.
# In Colab (GPU) raise to the full set.
TRAIN_SUBSET = int(os.environ.get("TRAIN_SUBSET", 2000))
TEST_SUBSET = int(os.environ.get("TEST_SUBSET", 1000))
BATCH_SIZE = int(os.environ.get("BATCH_SIZE", 16))
EPOCHS = int(os.environ.get("EPOCHS", 2))

keras.utils.set_random_seed(SEED)


def _decode_imdb_texts():
    """Decode the IMDB int sequences back to text for the HuggingFace tokenizer."""
    (x_train, y_train), (x_test, y_test) = keras.datasets.imdb.load_data(seed=SEED)
    word_index = keras.datasets.imdb.get_word_index()
    index_word = {i + 3: w for w, i in word_index.items()}
    index_word[0] = ""
    index_word[1] = ""
    index_word[2] = "[UNK]"

    def decode(seq):
        return " ".join(index_word.get(i, "") for i in seq if i > 2)

    train_texts = [decode(s) for s in x_train]
    test_texts = [decode(s) for s in x_test]
    return train_texts, y_train, test_texts, y_test


def _tfds(texts, labels, tokenizer, shuffle, batch_size):
    enc = tokenizer(list(texts), truncation=True, padding="max_length",
                    max_length=MAX_LEN, return_tensors="np")
    ds = tf.data.Dataset.from_tensor_slices(({
        "input_ids": enc["input_ids"],
        "attention_mask": enc["attention_mask"],
    }, labels))
    if shuffle:
        ds = ds.shuffle(len(labels), seed=SEED)
    return ds.batch(batch_size).prefetch(tf.data.AUTOTUNE)


def _evaluate(model, ds, y_true, label):
    out = model.predict(ds, verbose=0).logits
    y_pred = out.argmax(axis=1)
    acc = float((y_pred == y_true).mean())
    f1 = f1_score(y_true, y_pred, average="macro")
    loss = float(keras.losses.SparseCategoricalCrossentropy(from_logits=True)(y_true, out).numpy())
    print(f"\n[{label}]  acc {acc:.4f}  loss {loss:.4f}  F1 {f1:.4f}")
    print(classification_report(y_true, y_pred, digits=4))
    print(confusion_matrix(y_true, y_pred))
    return {"stage": label, "acc": acc, "loss": loss, "f1": f1}


def main():
    print(f"loading tokenizer and backbone: {MODEL_NAME}")
    tokenizer = DistilBertTokenizerFast.from_pretrained(MODEL_NAME)
    # use_safetensors=False -> downloads the legacy .bin so TF loader works without torch
    model = TFDistilBertForSequenceClassification.from_pretrained(
        MODEL_NAME, num_labels=2, use_safetensors=False)

    train_texts, y_train, test_texts, y_test = _decode_imdb_texts()
    if TRAIN_SUBSET > 0:
        idx = np.random.RandomState(SEED).permutation(len(y_train))[:TRAIN_SUBSET]
        train_texts = [train_texts[i] for i in idx]
        y_train = y_train[idx]
    if TEST_SUBSET > 0:
        idx = np.random.RandomState(SEED).permutation(len(y_test))[:TEST_SUBSET]
        test_texts = [test_texts[i] for i in idx]
        y_test = y_test[idx]

    train_ds = _tfds(train_texts, y_train, tokenizer, shuffle=True, batch_size=BATCH_SIZE)
    test_ds = _tfds(test_texts, y_test, tokenizer, shuffle=False, batch_size=BATCH_SIZE)
    print(f"train {len(y_train):,}, test {len(y_test):,}, max_len {MAX_LEN}, "
          f"batch {BATCH_SIZE}, epochs {EPOCHS}")

    # Zero-shot evaluation of the pretrained model BEFORE fine-tuning
    model.compile(optimizer=keras.optimizers.Adam(2e-5),
                  loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                  metrics=[keras.metrics.SparseCategoricalAccuracy("acc")])
    pre = _evaluate(model, test_ds, y_test, "pretrained_only")

    t0 = time.perf_counter()
    history = model.fit(train_ds, validation_data=test_ds, epochs=EPOCHS, verbose=1)
    train_time_s = time.perf_counter() - t0

    post = _evaluate(model, test_ds, y_test, "fine_tuned")

    df_hist = pd.DataFrame(history.history)
    df_hist.index.name = "epoch"
    df_hist.to_excel(RESULTS_DIR / "distilbert_epochs.xlsx")
    pd.DataFrame([
        {**pre, "train_time_s": 0.0, "train_subset": TRAIN_SUBSET, "test_subset": TEST_SUBSET,
         "epochs": 0},
        {**post, "train_time_s": train_time_s, "train_subset": TRAIN_SUBSET,
         "test_subset": TEST_SUBSET, "epochs": EPOCHS},
    ]).to_excel(RESULTS_DIR / "distilbert_summary.xlsx", index=False)
    print(f"\ntrain time: {train_time_s:.1f} s")


if __name__ == "__main__":
    main()
