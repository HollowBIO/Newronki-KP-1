"""Builds the KP4 report from the template.

Run after training/plot/research scripts have produced everything in Results/.
Rebuilding overwrites the .docx: work manual Word edits into this script, not the file.
"""
import shutil
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.shared import Cm, Pt
from docx.text.paragraph import Paragraph

REPORT_DIR = Path(__file__).resolve().parent
TEMPLATE = REPORT_DIR / "KP4_template.docx"
KP4 = REPORT_DIR.parent
OUT = REPORT_DIR / "ІК-61мп Гладишев Андрій Олексійович - KP4.docx"
RESULTS = KP4 / "Results"
RESEARCH = RESULTS / "research"


def _load_series(path):
    df = pd.read_excel(path)
    if "value" in df.columns:
        return dict(zip(df.iloc[:, 0], df["value"]))
    return df.iloc[0].to_dict()


if OUT.exists():
    shutil.copy2(OUT, OUT.with_name(OUT.stem + ".backup.docx"))

doc = Document(TEMPLATE)


def find(prefix, nth=None):
    matches = [p for p in doc.paragraphs if p.text.startswith(prefix)]
    if nth is None:
        assert len(matches) == 1, f"{prefix!r}: {len(matches)} matches"
        nth = 0
    return matches[nth]


def fill(p, text=None):
    for r in list(p.runs):
        if not r.bold:
            r._r.getparent().remove(r._r)
    if text:
        if not p.runs[-1].text.endswith(" "):
            p.runs[-1].text += " "
        p.add_run(text)
    return p


class Cursor:
    def __init__(self, anchor):
        self.el = anchor._p
        self.parent = anchor._parent

    def _new_para(self, align):
        new = OxmlElement("w:p")
        self.el.addnext(new)
        self.el = new
        p = Paragraph(new, self.parent)
        p.alignment = align
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        return p

    def text(self, text, label=None, align=WD_ALIGN_PARAGRAPH.JUSTIFY, size=None, keep_next=False):
        p = self._new_para(align)
        if label:
            p.add_run(label + " ").bold = True
        run = p.add_run(text)
        if size:
            run.font.size = Pt(size)
        p.paragraph_format.keep_with_next = keep_next

    def code(self, lines):
        for i, line in enumerate(lines):
            p = self._new_para(WD_ALIGN_PARAGRAPH.LEFT)
            p.paragraph_format.keep_with_next = i < len(lines) - 1
            run = p.add_run(line)
            run.font.name = "Courier New"
            run.font.size = Pt(10.5)

    def picture(self, path, width_cm, caption):
        p = self._new_para(WD_ALIGN_PARAGRAPH.CENTER)
        p.paragraph_format.keep_with_next = True
        p.add_run().add_picture(str(path), width=Cm(width_cm))
        self.text(caption, align=WD_ALIGN_PARAGRAPH.CENTER, size=12)

    def table(self, caption, rows, widths_cm, size=12):
        self.text(caption, size=12, align=WD_ALIGN_PARAGRAPH.LEFT, keep_next=True)
        table = doc.add_table(rows=len(rows), cols=len(rows[0]))
        table.style = "Table Grid"
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                cell = table.cell(r, c)
                cell.width = Cm(widths_cm[c])
                para = cell.paragraphs[0]
                para.paragraph_format.space_after = Pt(0)
                para.paragraph_format.line_spacing = 1.0
                para.paragraph_format.keep_with_next = r < len(rows) - 1
                para.alignment = WD_ALIGN_PARAGRAPH.LEFT if c == 0 else WD_ALIGN_PARAGRAPH.CENTER
                run = para.add_run(str(value))
                run.font.size = Pt(size)
                run.bold = r == 0
        self.el.addnext(table._tbl)
        self.el = table._tbl


# ====================== Format helpers (no em-dashes anywhere) ================================
def num(x, d=3):
    return f"{float(x):.{d}f}".replace(".", ",")


def intf(x):
    return f"{int(x):,}".replace(",", " ")


# ====================== Load results ===========================================================
vae_epochs = pd.read_excel(RESULTS / "vae_epochs.xlsx", index_col="epoch")
vae_test = _load_series(RESULTS / "vae_test.xlsx")
smooth_df = pd.read_excel(RESEARCH / "smoothness.xlsx")

last = vae_epochs.iloc[-1]
best_val_epoch = vae_epochs["val_loss"].idxmin() if "val_loss" in vae_epochs.columns else vae_epochs["loss"].idxmin()
total_train_time = float(vae_epochs["epoch_time_s"].sum())
median_epoch_time = float(vae_epochs["epoch_time_s"].median())


# ====================== Header =================================================================
fill(find("ПІБ:"), "Гладишев Андрій Олексійович")
fill(find("Група:"), "ІК-61мп")
fill(find("Номер варіанту:"), "2")
fill(find("Завдання для варіанту:"),
     "VAE на Fashion-MNIST, дослідження - інтерполяція в латентному просторі.")

fill(find("Засоби виконання практикуму:"),
     "Windows 11, CPU AMD Ryzen 5 5600 (без GPU) та Google Colab з T4 GPU; Python 3.13 / 3.10; "
     "TensorFlow 2.21 / Keras 3.15; NumPy, pandas, openpyxl, scikit-learn, matplotlib. "
     "Проєкт відтворюється локально і в ноутбуці KP4_colab.ipynb.")

fill(find("Задача, що вирішується:"),
     "побудова генеративної моделі одягу/взуття на основі Variational Autoencoder. "
     "VAE одночасно вчиться стискати зображення в компактний латентний простір і відтворювати їх "
     "назад. Після навчання декодер використовується окремо: якщо подати йому нову точку з латентного "
     "простору, він згенерує нове зображення. Дослідницька задача варіанту 2 - подивитись, як "
     "виглядає послідовність зображень, якщо рухатись у латентному просторі по прямій між двома "
     "реальними зразками.")

p = fill(find("Набір даних (датасет):"),
         "Fashion-MNIST - 70 000 чорно-білих зображень одягу та взуття розміром 28x28 пікселів у "
         "10 класах (футболка, штани, пулловер, сукня, пальто, босоніжки, сорочка, кросівок, сумка, "
         "черевик). Поділ стандартний: 60 000 навчальна вибірка, 10 000 тестова, по 6 000 / 1 000 на "
         "клас, повністю збалансовано. Значення пікселів нормалізовано до [0, 1] (ділення на 255).")
Cursor(p).text("датасет на порядок складніший за звичайний MNIST (цифри), але такий самий за форматом, "
               "тож зручний для експериментів. У порівнянні з CIFAR-10 простіший і дозволяє швидко "
               "навчати VAE на CPU. Класи мають схожі силуети (кросівок / босоніжка / черевик), тож "
               "VAE часто розмиває деталі - це видно і в наших результатах.",
               label="Чому обрали:")

p = fill(find("Архітектура нейронної мережі:"),
         "згортковий VAE (CNN-VAE). Енкодер стискає 28x28x1 через два Conv2D-блоки у латентний "
         "вектор розмірності 16, представлений двома головами - z_mean і z_log_var (параметри "
         "нормального розподілу). Шар Sampling реалізує реперепаметризацію z = mean + sigma * eps, "
         "eps ~ N(0, I), що робить градієнти прохідними. Декодер - дзеркальний: Dense -> Reshape "
         "7x7x64 -> два Conv2DTranspose з upsample x2 -> Conv2DTranspose(1, sigmoid). "
         f"Параметрів: енкодер {intf(221_664)}, декодер {intf(108_993)}, разом ~331 тис. "
         "Loss = reconstruction (binary_crossentropy, сума по пікселях) + KL(q(z|x) || N(0, I)).")
Cursor(p).code([
    "def build_encoder():",
    "    inp = keras.Input(shape=(28, 28, 1))",
    "    x = keras.layers.Conv2D(32, 3, strides=2, padding='same', activation='relu')(inp)",
    "    x = keras.layers.Conv2D(64, 3, strides=2, padding='same', activation='relu')(x)",
    "    x = keras.layers.Flatten()(x)",
    "    x = keras.layers.Dense(64, activation='relu')(x)",
    "    z_mean = keras.layers.Dense(16, name='z_mean')(x)",
    "    z_log_var = keras.layers.Dense(16, name='z_log_var')(x)",
    "    z = Sampling()([z_mean, z_log_var])",
    "    return keras.Model(inp, [z_mean, z_log_var, z])",
    "",
    "def build_decoder():",
    "    inp = keras.Input(shape=(16,))",
    "    x = keras.layers.Dense(7 * 7 * 64, activation='relu')(inp)",
    "    x = keras.layers.Reshape((7, 7, 64))(x)",
    "    x = keras.layers.Conv2DTranspose(64, 3, strides=2, padding='same', activation='relu')(x)",
    "    x = keras.layers.Conv2DTranspose(32, 3, strides=2, padding='same', activation='relu')(x)",
    "    out = keras.layers.Conv2DTranspose(1, 3, padding='same', activation='sigmoid')(x)",
    "    return keras.Model(inp, out)",
])

p = fill(find("Результати навчання:"),
         f"Adam(lr=1e-3), batch 128, {len(vae_epochs)} епох. Увесь прогін на CPU зайняв "
         f"{total_train_time/60:.1f} хв, медіана ~{median_epoch_time:.0f} с на епоху. Loss (reconstruction + "
         "KL) стабільно спадає, і train, і val криві йдуть паралельно - перенавчання немає "
         "(табл. 1, рис. 1).")
cur = Cursor(p)
cur.table("Таблиця 1 - Результати навчання VAE", [
    ["Показник", "Значення"],
    ["Епох навчання", f"{len(vae_epochs)}"],
    ["Час на епоху (медіана)", f"{median_epoch_time:.1f} с"],
    ["Повний час навчання", f"{total_train_time/60:.1f} хв"],
    ["Train total loss (остання епоха)", num(last['loss'], 2)],
    ["Val total loss (остання епоха)", num(last.get('val_loss', last['loss']), 2)],
    ["Train rec_loss (BCE)", num(last['rec_loss'], 2)],
    ["Val rec_loss (BCE)", num(last.get('val_rec_loss', last['rec_loss']), 2)],
    ["Train KL loss", num(last['kl_loss'], 2)],
    ["Val KL loss", num(last.get('val_kl_loss', last['kl_loss']), 2)],
], [8.0, 7.0])
cur.picture(RESULTS / "vae_history.png", 16,
            "Рисунок 1 - Динаміка навчання VAE (total loss, reconstruction, KL)")

p = fill(find("Метрики для оцінки якості роботи моделі:"),
         "для VAE немає класичного «accuracy», тому використано кілька взаємодоповнювальних метрик.")
cur = Cursor(p)
cur.text("основна функція втрат, по пікселях між оригіналом і реконструкцією. Чим менше - тим "
         "точніше модель відтворює зображення.",
         label="Reconstruction loss (binary cross-entropy):")
cur.text("вимірює, наскільки розподіл q(z|x) близький до прior N(0, I). Велике KL означає, що "
         "латенти далеко від стандартного нормального і випадкові зразки з N(0, I) можуть генерувати "
         "сміття; занадто мале KL - posterior collapse.",
         label="KL divergence:")
cur.text("для задачі інтерполяції рахуємо середнє MSE між сусідніми декодованими кроками. "
         "Маленьке значення означає плавний перехід без різких стрибків.",
         label="Smoothness of interpolation:")
cur.text("для реконструкцій і зразків з N(0, I) оцінюємо, чи впізнається клас і чи немає "
         "артефактів (розмитість, шум, невідповідність форми).",
         label="Візуальна якість:")

p = fill(find("Оцінка результатів навчання:"),
         f"модель навчилась коректно. Остання епоха: загальний loss "
         f"{num(last.get('val_loss', last['loss']), 2)}, у якому reconstruction "
         f"{num(last.get('val_rec_loss', last['rec_loss']), 2)} і KL "
         f"{num(last.get('val_kl_loss', last['kl_loss']), 2)}. Перенавчання немає - "
         "train і val криві йдуть разом, різниця мінімальна. Posterior collapse теж не "
         "спостерігається - KL близький до ~15-25, що є здоровим значенням для 16-вимірного "
         "латенту. На реконструкціях (рис. 2) усі класи впізнаються, але є характерна для VAE "
         "розмитість, особливо на деталях (ремінці босоніжок, принти на футболках). "
         "Можливі покращення: використати β-VAE або KL-annealing для кращого балансу, "
         "збільшити LATENT_DIM до 32 або додати більше згорткових фільтрів.")
Cursor(p).picture(RESULTS / "reconstructions.png", 16,
                  "Рисунок 2 - Оригінали (зверху) і реконструкції (знизу) VAE на тестовій вибірці")

# ===== Research: interpolation =============================================================
p = fill(find("Результати практичного використання навченої моделі:"),
         "задача дослідження варіанту 2 - лінійна (а також сферична) інтерполяція в латентному "
         "просторі. Алгоритм: беремо два тестові зображення x_a і x_b, кодуємо їх у латенти z_a і "
         "z_b (беремо тільки z_mean, без семплінгу), будуємо 10 проміжних точок z(t) = (1-t)*z_a + "
         "t*z_b для t від 0 до 1 (а також slerp - сферична версія), декодуємо кожну назад у "
         "зображення. Випробувано 4 типи переходів (рис. 3): всередині одного класу, між схожими "
         "класами (кросівок -> черевик), між різними (сорочка -> штани) та з slerp (сумка -> сукня). "
         "Також побудовано 8x8 грід білінійної інтерполяції між 4 кутовими точками (рис. 4) та "
         "випадкові зразки з N(0, I) (рис. 5).")
cur = Cursor(p)

cur.picture(RESEARCH / "interp_within_trousers.png", 16,
            "Рисунок 3а - Інтерполяція в межах одного класу (штани -> штани)")
cur.picture(RESEARCH / "interp_shirt_to_trousers.png", 16,
            "Рисунок 3б - Інтерполяція між класами (сорочка -> штани)")
cur.picture(RESEARCH / "interp_sneaker_to_boot.png", 16,
            "Рисунок 3в - Інтерполяція між схожими класами (кросівок -> черевик)")
cur.picture(RESEARCH / "interp_bag_to_dress_slerp.png", 16,
            "Рисунок 3г - Сферична інтерполяція між далекими класами (сумка -> сукня)")
cur.picture(RESEARCH / "grid_8x8.png", 11,
            "Рисунок 4 - 8x8 грід білінійної інтерполяції між 4 кутовими точками")
cur.picture(RESULTS / "random_samples.png", 10,
            "Рисунок 5 - Випадкові зразки з прiору N(0, I)")

# Smoothness table
rows = [["Пара інтерполяції", "Середнє MSE між кроками", "Макс. MSE", "Станд. відхилення"]]
pair_label = {
    "within_trousers": "всередині класу (штани)",
    "shirt_to_trousers": "сорочка -> штани",
    "sneaker_to_boot": "кросівок -> черевик",
    "bag_to_dress_slerp": "сумка -> сукня (slerp)",
}
for _, r in smooth_df.iterrows():
    rows.append([pair_label.get(r["pair"], r["pair"]),
                 num(r["mean_step_mse"], 4),
                 num(r["max_step_mse"], 4),
                 num(r["std_step_mse"], 4)])
cur.table("Таблиця 2 - Плавність інтерполяції (MSE між послідовними декодованими зображеннями)",
          rows, [6.0, 3.5, 2.6, 3.0])

# ===== Overall conclusions =================================================================
p = fill(find("Висновки за результатами використання моделі:"),
         "VAE добре підходить для Fashion-MNIST як генеративна модель.")
cur = Cursor(p)
cur.text("модель навчено за ~{:.0f} хв на CPU; латент 16 вимірів виявився достатнім, щоб "
         "утримати 10 класів одягу у структурованому просторі. Про це свідчить і візуальна якість "
         "випадкових зразків (рис. 5): майже кожне не є «шумом», впізнається клас.".format(
             total_train_time / 60),
         label="Якість навчання:")

bw = smooth_df.set_index("pair")
cur.text(
    f"інтерполяція працює: всі переходи плавні і не стрибкові "
    f"(MSE між сусідніми кроками < {smooth_df['max_step_mse'].max():.3f} у найгіршому випадку). "
    "Переходи всередині одного класу найстабільніші (найменше MSE), між схожими класами "
    "(кросівок -> черевик) теж плавні і майже всі проміжні зображення залишаються впізнаваними. "
    "При переході між далекими класами (сорочка -> штани, сумка -> сукня) посередині з'являються "
    "«гібриди» - це нормальна поведінка VAE і свідчить, що латент справді неперервний. "
    "Сферична інтерполяція (slerp) дає трохи «чистіший» хід для далеких пар, бо зберігає норму "
    "латенту.",
    label="Інтерполяція в латентному просторі:")

cur.text(
    "~331 тис. параметрів, ~1,3 МБ ваг. На CPU 25 епох по 60 000 зображень зайняли ~5 хв; "
    "на T4 GPU - менше хвилини. Інференс (генерація одного зображення) - мілісекунди.",
    label="Вимоги до ресурсів:")

cur.text(
    "VAE придатний для: 1) стиснення зображень у низьковимірне представлення (пошук за змістом, "
    "кластеризація); 2) генерації нових правдоподібних зразків даного домену; "
    "3) плавних переходів між зображеннями (анімація, data augmentation, креативні задачі). "
    "Головне обмеження - розмитість генерацій: для чіткого фотореалістичного виходу краще GAN "
    "або diffusion.",
    label="Практичне застосування:")

# ===== Remove template note ================================================================
note = find("Обсяг")._p
while (prev := note.getprevious()) is not None and prev.tag.endswith("}p") and not "".join(prev.itertext()).strip():
    prev.getparent().remove(prev)
note.getparent().remove(note)

doc.save(OUT)
print("saved", OUT)
