"""Loads Fashion-MNIST, normalises to [0, 1], saves as a cached .npz."""
from pathlib import Path

import numpy as np
from tensorflow import keras

KP4_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = KP4_DIR / "Data"
DATA_DIR.mkdir(exist_ok=True)

SEED = 42
CLASS_NAMES = ["T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
               "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"]


def _save():
    (x_train, y_train), (x_test, y_test) = keras.datasets.fashion_mnist.load_data()
    x_train = x_train.astype("float32") / 255.0
    x_test = x_test.astype("float32") / 255.0
    np.savez_compressed(DATA_DIR / "fashion_mnist.npz",
                        x_train=x_train, y_train=y_train, x_test=x_test, y_test=y_test)
    return x_train, y_train, x_test, y_test


def load():
    """Returns (x_train, y_train, x_test, y_test), float32 in [0, 1], shape 28x28."""
    path = DATA_DIR / "fashion_mnist.npz"
    if not path.exists():
        _save()
    d = np.load(path)
    return d["x_train"], d["y_train"], d["x_test"], d["y_test"]


if __name__ == "__main__":
    x_train, y_train, x_test, y_test = _save()
    print(f"train: {x_train.shape}, labels: {np.bincount(y_train)}")
    print(f"test:  {x_test.shape}, labels: {np.bincount(y_test)}")
    print(f"pixel range: [{x_train.min():.3f}, {x_train.max():.3f}]")
    print(f"saved to {DATA_DIR}")
