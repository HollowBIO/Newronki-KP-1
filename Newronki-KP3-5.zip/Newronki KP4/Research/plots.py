"""Training curve plots for the VAE."""
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

KP4 = Path(__file__).resolve().parent.parent
RES = KP4 / "Results"


def main():
    df = pd.read_excel(RES / "vae_epochs.xlsx", index_col="epoch")
    fig, ax = plt.subplots(1, 3, figsize=(13, 3.6))
    ax[0].plot(df.index, df["loss"], label="train", color="#1f77b4")
    if "val_loss" in df.columns:
        ax[0].plot(df.index, df["val_loss"], label="val", color="#ff7f0e")
    ax[0].set_title("Total loss"); ax[0].set_xlabel("epoch"); ax[0].legend(); ax[0].grid(alpha=0.3)
    ax[1].plot(df.index, df["rec_loss"], label="train", color="#1f77b4")
    if "val_rec_loss" in df.columns:
        ax[1].plot(df.index, df["val_rec_loss"], label="val", color="#ff7f0e")
    ax[1].set_title("Reconstruction loss (BCE)"); ax[1].set_xlabel("epoch"); ax[1].legend(); ax[1].grid(alpha=0.3)
    ax[2].plot(df.index, df["kl_loss"], label="train", color="#1f77b4")
    if "val_kl_loss" in df.columns:
        ax[2].plot(df.index, df["val_kl_loss"], label="val", color="#ff7f0e")
    ax[2].set_title("KL divergence"); ax[2].set_xlabel("epoch"); ax[2].legend(); ax[2].grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(RES / "vae_history.png", dpi=130)
    plt.close()
    print("saved", RES / "vae_history.png")


if __name__ == "__main__":
    main()
