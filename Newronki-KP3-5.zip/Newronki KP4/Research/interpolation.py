"""Interpolation in latent space for the trained VAE (variant 2 research task).

Does three experiments:
1. Linear interpolation between two test images from the SAME class (within-class morph).
2. Linear interpolation between two test images from DIFFERENT classes (between-class morph).
3. 2D grid of interpolations: for each pair in a 5x5 grid of latent points, decode.
Plus a reconstruction gallery (original vs reconstruction) and a KL/rec_loss by class table.
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from tensorflow import keras

KP4_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = KP4_DIR / "Data"
RESULTS_DIR = KP4_DIR / "Results"
RESEARCH_DIR = RESULTS_DIR / "research"
RESEARCH_DIR.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(DATA_DIR))
sys.path.insert(0, str(KP4_DIR / "VAEModel"))
from prepare_data import load, SEED, CLASS_NAMES  # noqa: E402
from vae import build_encoder, build_decoder, LATENT_DIM  # noqa: E402

N_STEPS = 10  # interpolation steps between a pair
rng = np.random.default_rng(SEED)


def _slerp(t, p0, p1):
    """Spherical linear interpolation (preserves norm, matters for the VAE latent)."""
    omega = np.arccos(np.clip(np.dot(p0 / np.linalg.norm(p0), p1 / np.linalg.norm(p1)), -1, 1))
    so = np.sin(omega) + 1e-8
    return np.sin((1 - t) * omega) / so * p0 + np.sin(t * omega) / so * p1


def _linear(t, p0, p1):
    return (1 - t) * p0 + t * p1


def pair_interpolation(encoder, decoder, x_a, x_b, mode="linear"):
    """Encode x_a, x_b to latent means, interpolate N_STEPS steps, decode."""
    z_a = encoder.predict(x_a[None, ..., None], verbose=0)[0][0]
    z_b = encoder.predict(x_b[None, ..., None], verbose=0)[0][0]
    ts = np.linspace(0, 1, N_STEPS)
    f = _slerp if mode == "slerp" else _linear
    zs = np.stack([f(t, z_a, z_b) for t in ts])
    imgs = decoder.predict(zs, verbose=0)[..., 0]
    return imgs


def show_strip(imgs, path, title):
    fig, axes = plt.subplots(1, len(imgs), figsize=(len(imgs) * 1.1, 1.4))
    for ax, im in zip(axes, imgs):
        ax.imshow(im, cmap="gray"); ax.axis("off")
    fig.suptitle(title, fontsize=11)
    plt.tight_layout()
    plt.savefig(path, dpi=130, bbox_inches="tight")
    plt.close()
    print("saved", path)


def grid_interpolation(decoder, p00, p01, p10, p11, n=8):
    """Bilinear interpolation between 4 corner latent points, decode as an n x n grid."""
    ts = np.linspace(0, 1, n)
    grid = np.zeros((n * 28, n * 28))
    for i, tv in enumerate(ts):
        row_left = (1 - tv) * p00 + tv * p10
        row_right = (1 - tv) * p01 + tv * p11
        for j, th in enumerate(ts):
            z = (1 - th) * row_left + th * row_right
            img = decoder.predict(z[None], verbose=0)[0, ..., 0]
            grid[i * 28:(i + 1) * 28, j * 28:(j + 1) * 28] = img
    return grid


def main():
    _, _, x_test, y_test = load()

    # Rebuild and load weights
    enc = build_encoder(LATENT_DIM)
    dec = build_decoder(LATENT_DIM)
    enc.load_weights(RESULTS_DIR / "vae_encoder.weights.h5")
    dec.load_weights(RESULTS_DIR / "vae_decoder.weights.h5")
    print("weights loaded")

    # 1) Reconstructions (same class vs original)
    sample_idx = rng.choice(len(x_test), size=10, replace=False)
    originals = x_test[sample_idx]
    recon = dec.predict(enc.predict(originals[..., None], verbose=0)[0], verbose=0)[..., 0]
    fig, axes = plt.subplots(2, 10, figsize=(12, 2.6))
    for i in range(10):
        axes[0, i].imshow(originals[i], cmap="gray"); axes[0, i].axis("off")
        axes[1, i].imshow(recon[i], cmap="gray"); axes[1, i].axis("off")
    axes[0, 0].set_ylabel("originals", fontsize=10)
    axes[1, 0].set_ylabel("decoder", fontsize=10)
    plt.suptitle("Фото і реконструкції (test set)", fontsize=11)
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "reconstructions.png", dpi=130, bbox_inches="tight")
    plt.close()
    print("saved reconstructions")

    # 2) Pair interpolations
    pairs = [
        # within class: two trousers
        ("within_trousers", 1, 1, "linear"),
        # between classes: shirt -> trousers
        ("shirt_to_trousers", 0, 1, "linear"),
        # between: sneaker -> ankle boot
        ("sneaker_to_boot", 7, 9, "linear"),
        # between (slerp): bag -> dress
        ("bag_to_dress_slerp", 8, 3, "slerp"),
    ]
    rows = []
    for name, cls_a, cls_b, mode in pairs:
        ia = rng.choice(np.where(y_test == cls_a)[0])
        ib = rng.choice(np.where(y_test == cls_b)[0])
        imgs = pair_interpolation(enc, dec, x_test[ia], x_test[ib], mode=mode)
        title = f"{CLASS_NAMES[cls_a]} -> {CLASS_NAMES[cls_b]}  ({mode}, {N_STEPS} кроків)"
        show_strip(np.concatenate([x_test[ia:ia + 1], imgs, x_test[ib:ib + 1]], axis=0),
                   RESEARCH_DIR / f"interp_{name}.png", title)
        rows.append({"pair": name, "class_a": CLASS_NAMES[cls_a], "class_b": CLASS_NAMES[cls_b],
                     "idx_a": int(ia), "idx_b": int(ib), "mode": mode, "steps": N_STEPS})
    pd.DataFrame(rows).to_excel(RESEARCH_DIR / "pairs.xlsx", index=False)

    # 3) 2D grid interpolation using 4 corner samples (shirt / trouser / sneaker / bag)
    corners = []
    for cls in (0, 1, 7, 8):  # shirt, trouser, sneaker, bag
        idx = rng.choice(np.where(y_test == cls)[0])
        z = enc.predict(x_test[idx:idx + 1, ..., None], verbose=0)[0][0]
        corners.append(z)
    grid = grid_interpolation(dec, corners[0], corners[1], corners[2], corners[3], n=8)
    plt.figure(figsize=(7, 7))
    plt.imshow(grid, cmap="gray"); plt.axis("off")
    plt.title("Білінійна інтерполяція між 4 латентними точками\n"
              "(верх: сорочка<->штани, низ: кросівок<->сумка)", fontsize=10)
    plt.tight_layout()
    plt.savefig(RESEARCH_DIR / "grid_8x8.png", dpi=130, bbox_inches="tight")
    plt.close()
    print("saved grid_8x8")

    # 4) Smoothness metric: for each pair, measure MSE between consecutive decoded steps
    smoothness = []
    for name, cls_a, cls_b, mode in pairs:
        ia = rng.choice(np.where(y_test == cls_a)[0])
        ib = rng.choice(np.where(y_test == cls_b)[0])
        imgs = pair_interpolation(enc, dec, x_test[ia], x_test[ib], mode=mode)
        diffs = np.mean(np.square(imgs[1:] - imgs[:-1]), axis=(1, 2))
        smoothness.append({"pair": name, "mean_step_mse": float(diffs.mean()),
                          "max_step_mse": float(diffs.max()), "std_step_mse": float(diffs.std())})
    pd.DataFrame(smoothness).to_excel(RESEARCH_DIR / "smoothness.xlsx", index=False)
    print(pd.DataFrame(smoothness))

    # 5) Random samples from the prior N(0, I)
    z_samples = rng.standard_normal((16, LATENT_DIM)).astype("float32")
    samples = dec.predict(z_samples, verbose=0)[..., 0]
    fig, axes = plt.subplots(4, 4, figsize=(5, 5))
    for ax, im in zip(axes.flat, samples):
        ax.imshow(im, cmap="gray"); ax.axis("off")
    plt.suptitle("Випадкові зразки з N(0, I)", fontsize=11)
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "random_samples.png", dpi=130, bbox_inches="tight")
    plt.close()
    print("saved random_samples")


if __name__ == "__main__":
    main()
