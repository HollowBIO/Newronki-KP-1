"""Convolutional VAE for Fashion-MNIST (variant 2).

Encoder: 28x28x1 -> Conv blocks -> Dense -> (z_mean, z_log_var), latent dim 16.
Decoder: z -> Dense -> ConvTranspose blocks -> 28x28x1 sigmoid.
Loss = binary_crossentropy reconstruction (per-image sum) + KL divergence.
"""
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras

KP4_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = KP4_DIR / "Data"
RESULTS_DIR = KP4_DIR / "Results"
RESULTS_DIR.mkdir(exist_ok=True)
sys.path.insert(0, str(DATA_DIR))
from prepare_data import load, SEED  # noqa: E402

LATENT_DIM = 16
BATCH = 128
EPOCHS = 25

keras.utils.set_random_seed(SEED)


class Sampling(keras.layers.Layer):
    """Reparameterization: z = mean + sigma * eps (eps ~ N(0, I))."""
    def call(self, inputs):
        z_mean, z_log_var = inputs
        eps = tf.random.normal(shape=tf.shape(z_mean))
        return z_mean + tf.exp(0.5 * z_log_var) * eps


def build_encoder(latent_dim=LATENT_DIM):
    inp = keras.Input(shape=(28, 28, 1))
    x = keras.layers.Conv2D(32, 3, strides=2, padding="same", activation="relu")(inp)
    x = keras.layers.Conv2D(64, 3, strides=2, padding="same", activation="relu")(x)
    x = keras.layers.Flatten()(x)
    x = keras.layers.Dense(64, activation="relu")(x)
    z_mean = keras.layers.Dense(latent_dim, name="z_mean")(x)
    z_log_var = keras.layers.Dense(latent_dim, name="z_log_var")(x)
    z = Sampling()([z_mean, z_log_var])
    return keras.Model(inp, [z_mean, z_log_var, z], name="encoder")


def build_decoder(latent_dim=LATENT_DIM):
    inp = keras.Input(shape=(latent_dim,))
    x = keras.layers.Dense(7 * 7 * 64, activation="relu")(inp)
    x = keras.layers.Reshape((7, 7, 64))(x)
    x = keras.layers.Conv2DTranspose(64, 3, strides=2, padding="same", activation="relu")(x)
    x = keras.layers.Conv2DTranspose(32, 3, strides=2, padding="same", activation="relu")(x)
    out = keras.layers.Conv2DTranspose(1, 3, padding="same", activation="sigmoid")(x)
    return keras.Model(inp, out, name="decoder")


class VAE(keras.Model):
    def __init__(self, encoder, decoder, **kw):
        super().__init__(**kw)
        self.encoder = encoder
        self.decoder = decoder
        self.total_loss = keras.metrics.Mean("loss")
        self.rec_loss = keras.metrics.Mean("rec_loss")
        self.kl_loss = keras.metrics.Mean("kl_loss")

    @property
    def metrics(self):
        return [self.total_loss, self.rec_loss, self.kl_loss]

    def train_step(self, data):
        x = data
        with tf.GradientTape() as tape:
            z_mean, z_log_var, z = self.encoder(x)
            x_rec = self.decoder(z)
            rec = tf.reduce_mean(
                tf.reduce_sum(
                    keras.losses.binary_crossentropy(x, x_rec), axis=(1, 2)))
            kl = tf.reduce_mean(
                -0.5 * tf.reduce_sum(1 + z_log_var - tf.square(z_mean) - tf.exp(z_log_var), axis=1))
            loss = rec + kl
        grads = tape.gradient(loss, self.trainable_weights)
        self.optimizer.apply_gradients(zip(grads, self.trainable_weights))
        self.total_loss.update_state(loss)
        self.rec_loss.update_state(rec)
        self.kl_loss.update_state(kl)
        return {m.name: m.result() for m in self.metrics}

    def test_step(self, data):
        x = data
        z_mean, z_log_var, z = self.encoder(x)
        x_rec = self.decoder(z)
        rec = tf.reduce_mean(
            tf.reduce_sum(keras.losses.binary_crossentropy(x, x_rec), axis=(1, 2)))
        kl = tf.reduce_mean(
            -0.5 * tf.reduce_sum(1 + z_log_var - tf.square(z_mean) - tf.exp(z_log_var), axis=1))
        loss = rec + kl
        self.total_loss.update_state(loss)
        self.rec_loss.update_state(rec)
        self.kl_loss.update_state(kl)
        return {m.name: m.result() for m in self.metrics}


class EpochTimer(keras.callbacks.Callback):
    def on_train_begin(self, logs=None):
        self.times = []

    def on_epoch_begin(self, epoch, logs=None):
        self.start = time.perf_counter()

    def on_epoch_end(self, epoch, logs=None):
        self.times.append(time.perf_counter() - self.start)


def main():
    x_train, _, x_test, _ = load()
    x_train = x_train[..., None]
    x_test = x_test[..., None]
    print(f"train {x_train.shape}, test {x_test.shape}")

    enc = build_encoder()
    dec = build_decoder()
    enc.summary()
    dec.summary()
    vae = VAE(enc, dec)
    vae.compile(optimizer=keras.optimizers.Adam(1e-3))

    timer = EpochTimer()
    hist = vae.fit(x_train, validation_data=(x_test,),
                   epochs=EPOCHS, batch_size=BATCH,
                   callbacks=[timer], verbose=2)

    df = pd.DataFrame(hist.history)
    df["epoch_time_s"] = timer.times
    df.index.name = "epoch"
    df.to_excel(RESULTS_DIR / "vae_epochs.xlsx")

    enc.save_weights(RESULTS_DIR / "vae_encoder.weights.h5")
    dec.save_weights(RESULTS_DIR / "vae_decoder.weights.h5")

    # Final test eval
    test_metrics = vae.evaluate(x_test, verbose=0, return_dict=True)
    pd.Series(test_metrics).to_frame("value").to_excel(RESULTS_DIR / "vae_test.xlsx")
    print("TEST:", test_metrics)
    print(f"params: encoder {enc.count_params():,}, decoder {dec.count_params():,}")


if __name__ == "__main__":
    main()
