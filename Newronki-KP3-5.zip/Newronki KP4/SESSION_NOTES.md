# KP4 - session notes (read to resume)

Last updated: 2026-10-14.

## The task

- Course "Нейронні мережі", КП №4 "Генеративні нейронні мережі та моделі".
  Student: **Гладишев Андрій Олексійович, ІК-61мп**.
- **Variant 2:** VAE on MNIST/Fashion-MNIST, research **"інтерполяція в латентному просторі"**.
- Task points: ознайомлення з моделлю, підготовка (train on Fashion-MNIST), базова генерація,
  дослідження (interpolation), оцінювання (rec_loss, KL, smoothness), analysis.

## Status

- [x] Data prep (`Data/prepare_data.py`) - Fashion-MNIST, [0,1] normalise.
- [x] VAE (`VAEModel/vae.py`) - convolutional VAE, latent dim 16, 25 epochs, CPU ~5 min.
      Final test: total loss 240.3, rec_loss 225.3, KL 15.0.
- [x] Research (`Research/interpolation.py`):
      4 pairs (within-class trousers; shirt->trousers; sneaker->boot; bag->dress slerp),
      8x8 bilinear grid, random samples from N(0,I), smoothness table.
- [x] Plots (`Research/plots.py`).
- [x] Report (`Report/build_report.py`) - zero em-dashes / en-dashes, only hyphens.
- [x] Colab notebook (`KP4_colab.ipynb`).

## Key results

- Training smooth, no overfitting (train/val curves overlap).
- Reconstructions blurry but class is always recognisable.
- Interpolation smoothness MSE: within-class 0.001, between classes 0.003-0.011. All transitions
  look plausible, intermediate frames morph through hybrid shapes.
- Random samples from N(0, I) look believable: ~90% recognisable as a class.

## Running order

```bash
pip install -r "Newronki KP4/requirements.txt"
python "Newronki KP4/Data/prepare_data.py"
python "Newronki KP4/VAEModel/vae.py"              # ~5 min on CPU
python "Newronki KP4/Research/interpolation.py"
python "Newronki KP4/Research/plots.py"
python "Newronki KP4/Report/build_report.py"
```

Lazy option: upload `KP4_colab.ipynb` to Colab, Runtime -> GPU, Run All.

## Decisions

- Fashion-MNIST over plain MNIST (richer visuals, same scale).
- Latent dim 16 (variant 1 did 2/8/32 ablation; variant 2 is interpolation, so one fixed dim).
- CNN encoder/decoder, not fully-connected (sharper outputs on 28x28).
- Loss = reconstruction (BCE, summed over pixels) + KL (summed over latent dims).
- Both linear and slerp interpolation (slerp reduces latent-norm distortion for far pairs).
- No em-dashes anywhere in the report per user request; only hyphens with spaces.
